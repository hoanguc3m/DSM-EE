##############################################################################
# DS Copula
##############################################################################
{
rm(list=ls(all=TRUE))
library(DSCopula)
set.seed(123)

## Simulate data
vPars = c(0.5,0.99,0.1^2)
#vParms = c(vPars[1],  log(vPars[2]/(1 - vPars[2])), 0.5*log(vPars[3])) # lambda0, B, sigma, nu

time_start = as.Date("2000-01-01")
time_end = as.Date("2010-01-01")
family = 1
seed = 0

datagen <- sim.DSCopula(time_start = time_start, time_end = time_end,
                         vPars = vPars, family = family, seed = seed)
plot(datagen$vKendalls, type = "l")
List_input <- DS_data(data.u = datagen$data.u, data.udate = datagen$data.udate, family = family,
                      est.start = time_start + 1, est.end = time_end - 1)

data   <- List_input$data
priors   <- List_input$priors
arg <- List_input$arg

DS_Gauss_Obj <- fit.DSCopula(data, priors, arg)
filter_Gauss_Obj <- filter.DSCopula(DS_Gauss_Obj)

}

##############################################################################
{
rm(list=ls(all=TRUE))
library(DSCopula)
set.seed(123)

## Simulate data
vPars = c(0.5,0.99,0.1^2, 7)

time_start = as.Date("2000-01-01")
time_end = as.Date("2010-01-01")
family = 2
seed = 0

# Check vUParms

datagen <- sim.DSCopula(time_start = time_start, time_end = time_end,
                         vPars = vPars, family = family, seed = seed)

List_input <- DS_data(data.u = datagen$data.u, data.udate = datagen$data.udate, family = family,
                      est.start = time_start + 1, est.end = time_end - 1)

data   <- List_input$data
priors   <- List_input$priors
arg <- List_input$arg

DS_Student_Obj <- fit.DSCopula(data, priors, arg)
filter_Stu_Obj <- filter.DSCopula(DS_Student_Obj)

hist(matrix(unlist(DS_Student_Obj$params), ncol = 4, byrow = T)[,4])
}

##############################################################################
{
rm(list=ls(all=TRUE))
library(DSCopula)
set.seed(123)

## Simulate data
vPars = c(0.5,0.99,0.1^2); family = 3 # Clayton
vPars = c(0.5,0.99,0.1^2); family = 4 # Gumbel
vPars = c(0.25,0.99,0.1^2); family = 5 # Frank does not go well
vPars = c(0.5,0.99,0.1^2); family = 6 # Joe

time_start = as.Date("2000-01-01")
time_end = as.Date("2010-01-01")
seed = 0

datagen <- sim.DSCopula(time_start = time_start, time_end = time_end,
                         vPars = vPars, family = family, seed = seed)

List_input <- DS_data(data.u = datagen$data.u, data.udate = datagen$data.udate, family = family,
                      est.start = time_start + 1, est.end = time_end - 1)

data   <- List_input$data
priors   <- List_input$priors
arg <- List_input$arg
plot(datagen$vKendalls, type = "l")
plot(datagen$vThetas, type = "l")

DS_Arch_Obj <- fit.DSCopula(data, priors, arg)
hist(matrix(unlist(DS_Arch_Obj$params), ncol = 3, byrow = T)[,1])
}

##############################################################################
# DS MIDAS Copula
##############################################################################
{
rm(list=ls(all=TRUE))
library(DSCopula)
set.seed(123)

## Simulate data
vPars = c(0.5,0.99,0.1^2, 0.5, 0.5, 7, 5) # lambda0, B, sigma, delta1, delta2, omega1, omega2.
#vParms = c(vPars[1],  log(vPars[2]/(1 - vPars[2])), 0.5*log(vPars[3])) # lambda0, B, sigma

time_start = as.Date("2000-01-01")
time_end = as.Date("2010-01-01")
family = 1
seed = 0
polynomial = "rbeta_w"
iK = 2; x.lag = 20;

datagen <- sim.DSMIDASCopula(time_start = time_start, time_end = time_end,
                      vPars = vPars,
                      polynomial = polynomial, iK = iK, x.lag = x.lag, family = family, seed = seed)
plot(datagen$vKendalls, type = "l")
plot(datagen$vThetas, type = "l")
plot(datagen$vLmean_T, type = "l")

List_input <- DSMIDAS_data(data.u = datagen$data.u, data.udate = datagen$data.udate,
                   data.x = datagen$data.x, data.xdate = datagen$data.xdate,
                    family = family, polynomial = polynomial,
                   x.lag = x.lag, est.start = time_start+1, est.end = time_end - 2)
data   <- List_input$data
priors   <- List_input$priors
arg <- List_input$arg

DSMIDAS_Gauss_Obj <- fit.DSMIDASCopula(data, priors, arg)
filter_Gauss_Obj <- filter.DSMIDASCopula(DSMIDAS_Gauss_Obj)

}

##############################################################################
{
rm(list=ls(all=TRUE))
library(DSCopula)
set.seed(123)

## Simulate data
vPars = c(0.5,0.99,0.1^2, 0.5, 0.5, 7, 5, 8) # lambda0, B, sigma, delta1, delta2, omega1, omega2, nu.
#vParms = c(vPars[1],  log(vPars[2]/(1 - vPars[2])), 0.5*log(vPars[3])) # lambda0, B, sigma

time_start = as.Date("2000-01-01")
time_end = as.Date("2010-01-01")
family = 2
seed = 0
polynomial = "rbeta_w"
iK = 2; x.lag = 20;

datagen <- sim.DSMIDASCopula(time_start = time_start, time_end = time_end,
                               vPars = vPars,
                               polynomial = polynomial, iK = iK, x.lag = x.lag, family = family, seed = seed)

List_input <- DSMIDAS_data(data.u = datagen$data.u, data.udate = datagen$data.udate,
                           data.x = datagen$data.x, data.xdate = datagen$data.xdate,
                           polynomial = polynomial, family = family,
                           x.lag = x.lag, est.start = time_start+1, est.end = time_end - 2)
data   <- List_input$data
priors   <- List_input$priors
arg <- List_input$arg

DSMIDAS_Student_Obj <- fit.DSMIDASCopula(data, priors, arg)
}
##############################################################################
{
rm(list=ls(all=TRUE))
library(DSCopula)
set.seed(123)

## Simulate data
vPars = c(0.5,0.99,0.1^2, 0.5, 0.5, 7, 5); family = 3 # Clayton
vPars = c(0.5,0.99,0.1^2, 0.5, 0.5, 7, 5); family = 4 # Gumbel
vPars = c(0.25,0.99,0.1^2, 0.3, 0.2, 7, 5); family = 5 # Frank does not go well
vPars = c(0.5,0.99,0.1^2, 0.5, 0.5, 7, 5); family = 6 # Joe

time_start = as.Date("2000-01-01")
time_end = as.Date("2010-01-01")
seed = 0
polynomial = "rbeta_w"
iK = 2; x.lag = 20;

datagen <- sim.DSMIDASCopula(time_start = time_start, time_end = time_end,
                               vPars = vPars,
                               polynomial = polynomial, iK = iK, x.lag = x.lag, family = family, seed = seed)
plot(datagen$vKendalls, type = "l")
plot(datagen$vThetas, type = "l")
plot(datagen$vLmean_T, type = "l")

List_input <- DSMIDAS_data(data.u = datagen$data.u, data.udate = datagen$data.udate,
                           data.x = datagen$data.x, data.xdate = datagen$data.xdate,
                           polynomial = polynomial, family = family,
                           x.lag = x.lag, est.start = time_start+1, est.end = time_end - 2)

data   <- List_input$data
priors   <- List_input$priors
arg <- List_input$arg


DSMIDAS_Arch_Obj <- fit.DSMIDASCopula(data, priors, arg)
}

##############################################################################
# Weighting scheme
##############################################################################
{ # beta_w
rm(list=ls(all=TRUE))
library(DSCopula)
set.seed(123)

## Simulate data
vPars = c(0.5,0.99,0.1^2, 0.5, 0.5, 2, 2, 7, 5, 8) # lambda0, B, sigma, delta1, delta2, omega1 (2,7), omega2 (2,5).
#vParms = c(vPars[1],  log(vPars[2]/(1 - vPars[2])), 0.5*log(vPars[3])) # lambda0, B, sigma

time_start = as.Date("2000-01-01")
time_end = as.Date("2010-01-01")
family = 2
seed = 0
polynomial = "beta_w"
iK = 2; x.lag = 20;

datagen <- sim.DSMIDASCopula(time_start = time_start, time_end = time_end,
                               vPars = vPars,
                               polynomial = polynomial, iK = iK, x.lag = x.lag, family = family, seed = seed)

List_input <- DSMIDAS_data(data.u = datagen$data.u, data.udate = datagen$data.udate,
                           data.x = datagen$data.x, data.xdate = datagen$data.xdate,
                           polynomial = polynomial, family = family,
                           x.lag = x.lag, est.start = time_start+1, est.end = time_end - 2)
data   <- List_input$data
priors   <- List_input$priors
arg <- List_input$arg

DSMIDAS_beta_Obj <- fit.DSMIDASCopula(data, priors, arg)

}
##############################################################################
{ # expalmon_w
rm(list=ls(all=TRUE))
library(DSCopula)
set.seed(123)

## Simulate data
vPars = c(0.5,0.99,0.1^2, 0.5, 0.5, 10/100, 10/100, -5/100, -10/100, 7) # lambda0, B, sigma, delta1, delta2, omega1 (4,7), omega2 (3,5).
# ( 10/100, -10/100) , 10/100 present for the peak at recent/lag, -10/100 for how long the effect.
#vParms = c(vPars[1],  log(vPars[2]/(1 - vPars[2])), 0.5*log(vPars[3])) # lambda0, B, sigma

time_start = as.Date("2000-01-01")
time_end = as.Date("2010-01-01")
family = 2
seed = 0
polynomial = "expalmon_w"
iK = 2; x.lag = 20;

datagen <- sim.DSMIDASCopula(time_start = time_start, time_end = time_end,
                               vPars = vPars,
                               polynomial = polynomial, iK = iK, x.lag = x.lag, family = family, seed = seed)

List_input <- DSMIDAS_data(data.u = datagen$data.u, data.udate = datagen$data.udate,
                           data.x = datagen$data.x, data.xdate = datagen$data.xdate,
                           polynomial = polynomial, family = family,
                           x.lag = x.lag, est.start = time_start+1, est.end = time_end - 2)
data   <- List_input$data
priors   <- List_input$priors
arg <- List_input$arg

DSMIDAS_expalmon_Obj <- fit.DSMIDASCopula(data, priors, arg)
}
