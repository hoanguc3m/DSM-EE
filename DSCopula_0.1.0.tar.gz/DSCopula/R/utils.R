#' Reduce the daily frequency data to monthly data
#'
#' Reduce the daily frequency data to monthly data
#' @param data.x The input data as matrix T x K where T is the number of observations and K is the number of variables
#' @param data.xdate The input vector of time series.
#' @return A list object of the data.xdate and data.xdate on that month.
#' @export
#' @examples
#' \dontrun{
#' }
reduce_monthdata <- function(data.x, data.xdate){
    if (!is.null(data.x)){
        if (!is.matrix(data.x)) data.x <- as.matrix(data.x, ncol = 1)
    }
    data.xdate_vec <- matrix(unlist(date_vec(data.xdate)), nrow = length(data.xdate))
    YM_code <- data.xdate_vec[,1] * 100 + data.xdate_vec[,2]
    YMD_code <- data.xdate_vec[,1] * 10000 + data.xdate_vec[,2] * 100 + data.xdate_vec[,3]
    uniqueMonth <- unique(YM_code)
    lengUniqeMonth <- length(uniqueMonth)
    MonthSelect <- sapply(uniqueMonth, FUN = function(MonthID) MonthID == YM_code )
    if (length(MonthSelect) == 1){
        id_month <- 1
    } else {
        id_month <- apply(MonthSelect, MARGIN = 2, FUN = function(MonthID) (1:length(data.xdate))[MonthID][1])
    }


    return(list(data.xdate = data.xdate[id_month, drop = FALSE],
                data.x = data.x[id_month,]))
}

#' Get monthly realized volatility from daily data
#' @export
RealizedVol <- function(data.x, data.xdate){
    if (!is.matrix(data.x)) data.x <- as.matrix(data.x, ncol = 1)
    data.xdate_vec <- matrix(unlist(date_vec(data.xdate)), nrow = length(data.xdate))
    YM_code <- data.xdate_vec[,1] * 100 + data.xdate_vec[,2]
    YMD_code <- data.xdate_vec[,1] * 10000 + data.xdate_vec[,2] * 100 + data.xdate_vec[,3]
    uniqueMonth <- unique(YM_code)
    lengUniqeMonth <- length(uniqueMonth)
    MonthSelect <- sapply(uniqueMonth, FUN = function(MonthID) MonthID == YM_code )
    id_month <- apply(MonthSelect, MARGIN = 2, FUN = function(MonthID) (1:length(data.xdate))[MonthID][1])

    dataMonth <- sapply(c(1:ncol(MonthSelect)),
                        FUN = function(MonthID) sqrt(mean(data.x[MonthSelect[, MonthID]]^2))  )

    return(list(data.xdate = data.xdate[id_month, drop = FALSE],
                data.x = dataMonth))
}

#' Get monthly realized volatility from daily data
#' @export
RealizedRollingVol <- function(data.x, dateInMonth = 22){

    dataMonth <- sapply(c((dateInMonth):length(data.x)),
                        FUN = function(MonthID) sqrt(mean(data.x[(MonthID-dateInMonth+1):MonthID]^2))  )
    dataMonth <- c(rep(NA,dateInMonth-1), dataMonth)
    return(dataMonth)
}
#' Get realized correlation from daily data
#' @export
RealizedCor <- function(data.x, data.xdate){
    # Return the realized correlation during the month, ignore the date index
    if (!is.matrix(data.x)) data.x <- as.matrix(data.x, ncol = 1)
    data.xdate_vec <- matrix(unlist(date_vec(data.xdate)), nrow = length(data.xdate))
    YM_code <- data.xdate_vec[,1] * 100 + data.xdate_vec[,2]
    YMD_code <- data.xdate_vec[,1] * 10000 + data.xdate_vec[,2] * 100 + data.xdate_vec[,3]
    uniqueMonth <- unique(YM_code)
    lengUniqeMonth <- length(uniqueMonth)
    MonthSelect <- sapply(uniqueMonth, FUN = function(MonthID) MonthID == YM_code )

    id_month <- apply(MonthSelect, MARGIN = 2, FUN = function(MonthID) (1:length(data.xdate))[MonthID][1])
    dataMonth <- sapply(c(1:ncol(MonthSelect)),
                        FUN = function(MonthID) cor(data.x[MonthSelect[, MonthID],])[1,2] )

    return(list(data.xdate = data.xdate[id_month, drop = FALSE],
                data.x = dataMonth))
}
#' Get realized correlation from daily data
#' @export
RealizedCov <- function(data.x, data.xdate){
    # Return the realized correlation during the month, ignore the date index
    if (!is.matrix(data.x)) data.x <- as.matrix(data.x, ncol = 1)
    data.xdate_vec <- matrix(unlist(date_vec(data.xdate)), nrow = length(data.xdate))
    YM_code <- data.xdate_vec[,1] * 100 + data.xdate_vec[,2]
    YMD_code <- data.xdate_vec[,1] * 10000 + data.xdate_vec[,2] * 100 + data.xdate_vec[,3]
    uniqueMonth <- unique(YM_code)
    lengUniqeMonth <- length(uniqueMonth)
    MonthSelect <- sapply(uniqueMonth, FUN = function(MonthID) MonthID == YM_code )

    id_month <- apply(MonthSelect, MARGIN = 2, FUN = function(MonthID) (1:length(data.xdate))[MonthID][1])
    dataMonth <- sapply(c(1:ncol(MonthSelect)),
                        FUN = function(MonthID) cov(data.x[MonthSelect[, MonthID],])[1,2] )

    return(list(data.xdate = data.xdate[id_month, drop = FALSE],
                data.x = dataMonth))
}

#' Get the high frequency data at a specific day of the month
#'
#' Get the high frequency data at a specific day of the month
#' @param data.x The input data as matrix T x K where T is the number of observations and K is the number of variables
#' @param data.xdate The input vector of time series.
#' @param dayID The number at which the data are extracted.
#' @return A list object of the data.xdate and data.xdate on dayID.
#' @export
#' @examples
#' \dontrun{
#' n = 5000
#' data.u <- matrix(seq(from = 0, to = 1 - 1/(2*n), length.out = 2*n), ncol = 2)
#' rbind(head(data.u), tail(data.u))
#' data.udate <- seq(from = as.Date("2010-01-01"), by = 1, length.out = n)
#'
#' k <- 2
#' data.x <- matrix(seq(from = 0, to = 1 - 1/(2*n), length.out = k*n), ncol = k)
#' data.xdate <- seq(from = as.Date("2010-01-01"), by = 1, length.out = n)
#' month_reduce <- get_monthdata(data.x = data.x, data.xdate = data.xdate)
#' data.x <- month_reduce$data.x
#' data.xdate <- month_reduce$data.xdate
#' }
get_monthdata <- function(data.x, data.xdate, dayID = 1){
    if (!is.null(data.x)){
        if (!is.matrix(data.x)) data.x <- as.matrix(data.x, ncol = 1)
    }
    data.xdate_vec <- matrix(unlist(date_vec(data.xdate)), nrow = length(data.xdate))
    id_month <- data.xdate_vec[,3] == dayID
    return(list(data.xdate = data.xdate[id_month, drop = FALSE],
                data.x = data.x[id_month,, drop = FALSE]))
}

#' Get the mumber of daily observations in from a monthly series
#'
#' Get the mumber of daily observations in from a monthly series
#' @param est.xdate The input vector of monthly time series.
#' @param est.udate The input vector of daily time series.
#' @return A vector object of the how many day of est.udate in est.xdate.
#' @export
#' @examples
#' \dontrun{
#'
#' est.start <- as.Date("2012-01-01")
#' est.end <- as.Date("2017-03-01")
#'
#' dataMF <- DSMIDAS_data(data.u = data.u, data.udate = data.udate,
#'                   data.x = data.x, data.xdate = data.xdate,
#'                   x.lag = 9, u.lag = 1, horizon = 1,
#'                   est.start = est.start, est.end = est.end)
#' est.xdate <- dataMF$est.xdate
#' est.udate <- dataMF$est.udate
#'
#' rep_x = rep_reduce(est.xdate, est.udate)
#' rep_vector(rep_x = rep_x, vectorx = rnorm(length(rep_x)))
#' }
rep_reduce <- function(est.xdate, est.udate){
    # data.xdate_vec <- matrix(unlist(date_vec(est.xdate)), nrow = length(est.xdate))
    # data.udate_vec <- matrix(unlist(date_vec(est.udate)), nrow = length(est.udate))
    # rep_x <- rep(0, nrow(data.xdate_vec))
    # for (i in seq(nrow(data.xdate_vec))){
    #     rep_x[i] <- sum( (data.xdate_vec[i,1] == data.udate_vec[,1]) & (data.xdate_vec[i,2] == data.udate_vec[,2]) )
    # }
    rep_x <- rep(0, length(est.xdate))
    rep_x[length(est.xdate)] <- sum(est.xdate[length(est.xdate)] <= est.udate)
    for (i in seq(length(est.xdate) - 1, 1, by = -1 )){
        rep_x[i] <- sum(est.xdate[i] <= est.udate & est.xdate[i+1] > est.udate  )
    }
    return(rep_x)
}

#' MIDAS data structure
#'
#' @description
#' Creates a MIDAS data structure for a DS MIDAS Copula.
#' @param data.u The copula data as matrix T x 2 where T is the number of observations.
#' @param data.udate The vector of date vector length T of data.u.
#' @param data.x The low frequency exogenous variables as data matrix t x K where t is the number of observations.
#' @param data.xdate The vector of date vector length t of data.x.
#' @param x.lag number of low-frequency lags to construct in high-frequency time units.
#' @param y.lag number of high-frequency lags to construct in low-frequency time units.
#' @param horizon forecast horizon relative to date in high-frequency time units.
#' @param est.start estimation start date.
#' @param est.end estimation end date.
#' @return a list of MIDAS data structure.
#' @export
#' @examples
#' \dontrun{
#' n = 5000
#' data.u <- matrix(seq(from = 0, to = 1 - 1/(2*n), length.out = 2*n), ncol = 2)
#' rbind(head(data.u), tail(data.u))
#' data.udate <- seq(from = as.Date("2010-01-01"), by = 1, length.out = n)
#'
#' k <- 2
#' data.x <- matrix(seq(from = 0, to = 1 - 1/(2*n), length.out = k*n), ncol = k)
#' data.xdate <- seq(from = as.Date("2010-01-01"), by = 1, length.out = n)
#' month_reduce <- get_monthdata(data.x = data.x, data.xdate = data.xdate)
#' data.x <- month_reduce$data.x
#' data.xdate <- month_reduce$data.xdate
#'
#' est.start <- as.Date("2012-01-01")
#' est.end <- as.Date("2017-03-01")
#'
#' dataMF <- DSMIDAS_data(data.u = data.u, data.udate = data.udate,
#'                   data.x = data.x, data.xdate = data.xdate,
#'                   x.lag = 9, u.lag = 1, horizon = 1, family = 1, polynomial = "rbeta_w",
#'                   est.start = est.start, est.end = est.end)
#' est.xdate <- dataMF$est.xdate
#' est.udate <- dataMF$est.udate
#'
#' rep_x = rep_reduce(est.xdate, est.udate)
#' rep_vector(rep_x = rep_x, vectorx = rnorm(length(rep_x)))
#' }
DSMIDAS_data <- function (data.u, data.udate, data.x, data.xdate,
                     x.lag, x.lag2 = 0, family, polynomial, est.start, est.end, seed = NULL,...){

    data.udate_vec <- as.Date(data.udate)
    data.xdate_vec <- as.Date(data.xdate)
    est.start <- as.Date(est.start)
    est.end <- as.Date(est.end)
    data.udate_vec <- date_vec(data.udate)
    data.xdate_vec <- date_vec(data.xdate)
    data.udate_vec <- matrix(unlist(data.udate_vec), nrow = length(data.udate))
    data.xdate_vec <- matrix(unlist(data.xdate_vec), nrow = length(data.xdate))
    data.udate.num <- data.udate
    data.xdate.num <- data.xdate
    date.format = c("year(s)", "month(s)", "day(s)", "hour(s)",
                    "minute(s)", "second(s)")
    # Notes:
    #
    # Frequency   period   unit
    # yearly         1      1
    # semiannual     6      2
    # quarterly      3      2
    # monthly        1      2
    # biweekly       14     3
    # weekly         7      3
    # daily          1      3
    # hourly         1      4
    # minutely       1      5
    # secondly       1      6
    period.u <- data_freq(data.udate_vec)$period
    unit.u <- data_freq(data.udate_vec)$unit
    period.x <- data_freq(data.xdate_vec)$period
    unit.x <- data_freq(data.xdate_vec)$unit

    u.lag <- 1
    x.lag <- lag_num(x.lag, period.x, unit.x)
    if (x.lag2 > 0 ) x.lag2 <- lag_num(x.lag2, period.x, unit.x)

    horizon <- 1
    iK = ncol(data.x)

    if (u.lag < 0) {
        stop("u.lag cannot be negative.")
    }
    if (x.lag < 0) {
        stop("x.lag cannot be negative")
    }
    min.date.u <- data.udate.num[u.lag + 1]
    min.date.x <- data.xdate.num[max(1, x.lag + horizon)]

    if (min.date.u > min.date.x) {
        min.date <- min.date.u
    } else {
        min.date <- min.date.x
    }

    max.date.u <- data.udate.num[length(data.udate.num)]
    max.date.x <- data.xdate.num[length(data.xdate.num)]

    if (horizon < 0) {
        max.date.x <- data.xdate_vec[dim(data.xdate_vec)[1], ]
        max.date.x[unit.x] <- max.date.x[unit.x] + period.x * horizon
        max.date.x <- ISOdate(max.date.x[1], max.date.x[2], max.date.x[3],
                              max.date.x[4], max.date.x[5], max.date.x[6])
        max.date.x <- as.Date(max.date.x)
    }
    #max.date <- max.date.u # It might be a bug here

    if (zoo::as.yearmon(max.date.u) > zoo::as.yearmon(max.date.x)) {
        max.date <- max.date.x
    } else {
        max.date <- max.date.u
    }

    if (is.null(est.start)) {
        est.start <- min.date
    } else {
        if (est.start < min.date) {
            warning("Start date cannot be earlier than possible due to lagged regressors. Reset start date to most recent possible.")
            est.start <- min.date
        }
    }
    if (is.null(est.end)) {
        est.end <- max.date
    } else {
        if (est.end > max.date) {
            warning("Terminal date cannot be later than largest date account for lags. Reset to largest date.")
            est.end <- max.date
        }
    }
    tol <- 1e-10

    loc.start <- min(which((data.udate.num >= est.start - tol) == TRUE))
    loc.end <- min(which((data.udate.num >= est.end - tol) == TRUE))

    est.u <- data.u[loc.start:loc.end, , drop = FALSE]
    est.udate <- data.udate.num[loc.start:loc.end, drop = FALSE]

    if (exists("datagen")) {
        est.vThetas <- datagen$vThetas[loc.start:loc.end, drop = FALSE]
        est.vFactors <- datagen$vFactors[loc.start:loc.end, drop = FALSE]
        est.vOmega_T <- datagen$vOmega_T[loc.start:loc.end, drop = FALSE]
    } else {
        est.vThetas <- NULL
        est.vFactors <- NULL
        est.vOmega_T <- NULL
    }

    loc.forecast.end <- min(which((data.udate.num >= max.date - tol) == TRUE))

    if (loc.end + 1 <= loc.forecast.end) {
        out.u <- data.u[seq(loc.end + 1, loc.forecast.end, by = 1),, drop = FALSE]
        out.udate <- data.udate.num[seq(loc.end + 1, loc.forecast.end, by = 1), drop = FALSE]
        n.forecast <- nrow(out.u)
    } else {
        out.u <- out.udate <- NULL
        n.forecast <- nrow(out.u)
    }

    if (exists("datagen")) {
        out.vThetas <- datagen$vThetas[seq(loc.end + 1, loc.forecast.end, by = 1), drop = FALSE]
        out.vFactors <- datagen$vFactors[seq(loc.end + 1, loc.forecast.end, by = 1), drop = FALSE]
        out.vOmega_T <- datagen$vOmega_T[seq(loc.end + 1, loc.forecast.end, by = 1), drop = FALSE]
    } else {
        out.vThetas <- NULL
        out.vFactors <- NULL
        out.vOmega_T <- NULL
    }


    nobs <- loc.end - loc.start + 1
    # lag.u = 1
    est.lag.u <- data.u[seq(loc.start - 1, loc.end - 1, 1), ]
    est.lag.udate <- data.udate.num[seq(loc.start - 1, loc.end - 1, 1)]

    if (loc.end + 1 <= loc.forecast.end) {
        out.lag.u <- data.u[seq(loc.end, loc.forecast.end - 1, 1),]
        out.lag.udate <- data.udate.num[seq(loc.end, loc.forecast.end - 1, 1)]
    } else {
        out.lag.u <- out.lag.udate <- NULL
    }
    #cbind(head(out.udate), head(out.lag.udate), head(est.udate), head(est.lag.udate))

    if (x.lag2 == 0){
        est.xdate <- reduce_monthdata(data.x = NULL, est.udate)$data.xdate
        est.x <- matrix(NA, nrow = length(est.xdate), ncol = x.lag * ncol(data.x))
        data.est.xdate_vec <- date_vec(est.xdate)[[1]]
        tmp.est.xdate <- as.Date(ISOdate(data.est.xdate_vec[,1], data.est.xdate_vec[,2], 1))

        for (t in seq(length(est.xdate))) {
            # take the one lag at time t
            loc <- min(which((data.xdate.num >= tmp.est.xdate[t] - tol) == TRUE)) # Change here
            est.x[t,] = vec(data.x[(loc - 1):(loc - x.lag), , drop = FALSE])
        }

        out.xdate <- reduce_monthdata(data.x = NULL, out.udate)$data.xdate
        out.x <- matrix(NA, nrow = length(out.xdate), ncol = x.lag * ncol(data.x))
        data.out.xdate_vec <- date_vec(out.xdate)[[1]]
        tmp.out.xdate <- as.Date(ISOdate(data.out.xdate_vec[,1], data.out.xdate_vec[,2], 1))
        for (t in seq(length(out.xdate))) {
            # take the one lag at time t
            loc <- min(which((data.xdate.num >= tmp.out.xdate[t] - tol) == TRUE))
            out.x[t,] = vec(data.x[(loc - 1):(loc - x.lag), , drop = FALSE])
        }
        est.x2 = NULL; out.x2 = NULL;
    } else {
        est.xdate <- reduce_monthdata(data.x = NULL, est.udate)$data.xdate
        est.x <- matrix(NA, nrow = length(est.xdate), ncol = x.lag * 1)
        est.x2 <- matrix(NA, nrow = length(est.xdate), ncol = x.lag2 * 1)

        data.est.xdate_vec <- date_vec(est.xdate)[[1]]
        tmp.est.xdate <- as.Date(ISOdate(data.est.xdate_vec[,1], data.est.xdate_vec[,2], 1))

        for (t in seq(length(est.xdate))) {
            # take the one lag at time t
            loc <- min(which((data.xdate.num >= tmp.est.xdate[t] - tol) == TRUE)) # Change here
            est.x[t,] = vec(data.x[(loc - 1):(loc - x.lag), 1, drop = FALSE])
            est.x2[t,] = vec(data.x[(loc - 1):(loc - x.lag2), 2, drop = FALSE])
        }

        out.xdate <- reduce_monthdata(data.x = NULL, out.udate)$data.xdate
        out.x <- matrix(NA, nrow = length(out.xdate), ncol = x.lag * 1)
        out.x2 <- matrix(NA, nrow = length(out.xdate), ncol = x.lag2 * 1)

        data.out.xdate_vec <- date_vec(out.xdate)[[1]]
        tmp.out.xdate <- as.Date(ISOdate(data.out.xdate_vec[,1], data.out.xdate_vec[,2], 1))
        for (t in seq(length(out.xdate))) {
            # take the one lag at time t
            loc <- min(which((data.xdate.num >= tmp.out.xdate[t] - tol) == TRUE))
            out.x[t,] = vec(data.x[(loc - 1):(loc - x.lag), 1, drop = FALSE])
            out.x2[t,] = vec(data.x[(loc - 1):(loc - x.lag2), 2, drop = FALSE])
        }
    }

    data = list(est.u = est.u, est.udate = est.udate,
                  est.lag.u = est.lag.u, est.lag.udate = est.lag.udate,
                  out.u = out.u, out.udate = out.udate,
                  out.lag.u = out.lag.u, out.lag.udate = out.lag.udate,
                  est.xdate = est.xdate, est.x = est.x, out.x = out.x, out.xdate = out.xdate,
                  est.x2 = est.x2, out.x2 = out.x2, x.lag2 = x.lag2,
                  est.vThetas = est.vThetas, est.vFactors = est.vFactors, est.vOmega_T = est.vOmega_T,
                  out.vThetas = out.vThetas, out.vFactors = out.vFactors, out.vOmega_T = out.vOmega_T,
                  x.lag = x.lag, u.lag = u.lag, min.date = min.date, max.date = max.date,
                  iK = iK)
    if (polynomial == "expalmon_w"){
        priors   <- list(prior_Lambda0 = c(0,5),
                         prior_B = c(20, 1.5),
                         prior_Sigma = c(0.5,0.5/1),
                         prior_delta = c(0,5),
                         prior_omega1 = c(0.1,1),
                         prior_omega2 = c(-0.1,-0.01),
                         prior_nu = c(1,0.1))

    } else {
        priors   <- list(prior_Lambda0 = c(0,5),
                         prior_B = c(20, 1.5),
                         #prior_Sigma = c(5,0.01),
                         prior_Sigma = c(0.5,0.5/1),
                         prior_delta = c(0,1),
                         prior_omega1 = c(1,1),
                         prior_omega2 = c(1,30),
                         prior_nu = c(1,0.1))

    }
    arg <- list(T_anneal = 10000,       # Number of annealing steps
                M        = 1000,        # Number of annealing IS steps -> Number of particles in each annealing stage
                K        = 10,        # Number of Markov moves
                N        = 100,        # Number of particles in particle filter
                scaleCov = 0.1,        # Scale factor of covariance matrix for adaptive Markov move
                rho_corr = 0.999,
                seed = seed,
                family = family,
                polynomial = polynomial, iK = iK, x.lag = x.lag)


    return(list(data = data, priors = priors, arg = arg))
}

#' @export
DS_data <- function (data.u, data.udate, family, est.start, est.end, seed = NULL, ...){

    data.udate_vec <- as.Date(data.udate)
    est.start <- as.Date(est.start)
    est.end <- as.Date(est.end)
    data.udate_vec <- date_vec(data.udate)
    data.udate_vec <- matrix(unlist(data.udate_vec), nrow = length(data.udate))
    data.udate.num <- data.udate
    date.format = c("year(s)", "month(s)", "day(s)", "hour(s)",
                    "minute(s)", "second(s)")
    # Notes:
    #
    # Frequency   period   unit
    # yearly         1      1
    # semiannual     6      2
    # quarterly      3      2
    # monthly        1      2
    # biweekly       14     3
    # weekly         7      3
    # daily          1      3
    # hourly         1      4
    # minutely       1      5
    # secondly       1      6
    period.u <- data_freq(data.udate_vec)$period
    unit.u <- data_freq(data.udate_vec)$unit

    u.lag <- 1
    min.date.u <- data.udate.num[u.lag + 1]
    min.date <- min.date.u

    max.date.u <- data.udate.num[length(data.udate.num)]
    max.date <- max.date.u


    if (is.null(est.start)) {
        est.start <- min.date
    } else {
        if (est.start < min.date) {
            warning("Start date cannot be earlier than possible due to lagged regressors. Reset start date to most recent possible.")
            est.start <- min.date
        }
    }
    if (is.null(est.end)) {
        est.end <- max.date
    } else {
        if (est.end > max.date) {
            warning("Terminal date cannot be later than largest date account for lags. Reset to largest date.")
            est.end <- max.date
        }
    }
    tol <- 1e-10

    loc.start <- min(which((data.udate.num >= est.start - tol) == TRUE))
    loc.end <- min(which((data.udate.num >= est.end - tol) == TRUE))

    est.u <- data.u[loc.start:loc.end, , drop = FALSE]
    est.udate <- data.udate.num[loc.start:loc.end, drop = FALSE]

    if (exists("datagen")) {
        est.vThetas <- datagen$vThetas[loc.start:loc.end, drop = FALSE]
        est.vFactors <- datagen$vFactors[loc.start:loc.end, drop = FALSE]
        est.vOmega_T <- datagen$vOmega_T[loc.start:loc.end, drop = FALSE]
    } else {
        est.vThetas <- NULL
        est.vFactors <- NULL
        est.vOmega_T <- NULL
    }

    loc.forecast.end <- min(which((data.udate.num >= max.date - tol) == TRUE))

    if (loc.end + 1 <= loc.forecast.end) {
        out.u <- data.u[seq(loc.end + 1, loc.forecast.end, by = 1),, drop = FALSE]
        out.udate <- data.udate.num[seq(loc.end + 1, loc.forecast.end, by = 1), drop = FALSE]
        n.forecast <- nrow(out.u)
    } else {
        out.u <- out.udate <- NULL
        n.forecast <- nrow(out.u)
    }

    if (exists("datagen")) {
        out.vThetas <- datagen$vThetas[seq(loc.end + 1, loc.forecast.end, by = 1), drop = FALSE]
        out.vFactors <- datagen$vFactors[seq(loc.end + 1, loc.forecast.end, by = 1), drop = FALSE]
        out.vOmega_T <- datagen$vOmega_T[seq(loc.end + 1, loc.forecast.end, by = 1), drop = FALSE]
    } else {
        out.vThetas <- NULL
        out.vFactors <- NULL
        out.vOmega_T <- NULL
    }


    nobs <- loc.end - loc.start + 1
    # lag.u = 1
    est.lag.u <- data.u[seq(loc.start - 1, loc.end - 1, 1), ]
    est.lag.udate <- data.udate.num[seq(loc.start - 1, loc.end - 1, 1)]

    if (loc.end + 1 <= loc.forecast.end) {
        out.lag.u <- data.u[seq(loc.end, loc.forecast.end - 1, 1),]
        out.lag.udate <- data.udate.num[seq(loc.end, loc.forecast.end - 1, 1)]
    } else {
        out.lag.u <- out.lag.udate <- NULL
    }

    data = list(est.u = est.u, est.udate = est.udate,
                est.lag.u = est.lag.u, est.lag.udate = est.lag.udate,
                out.u = out.u, out.udate = out.udate,
                out.lag.u = out.lag.u, out.lag.udate = out.lag.udate,
                est.vThetas = est.vThetas, est.vFactors = est.vFactors, est.vOmega_T = est.vOmega_T,
                out.vThetas = out.vThetas, out.vFactors = out.vFactors, out.vOmega_T = out.vOmega_T,
                u.lag = u.lag, min.date = min.date, max.date = max.date)

    priors   <- list(prior_Lambda0 = c(0,5),
                     prior_B = c(20, 1.5),
                     #prior_Sigma = c(5,0.01),
                     prior_Sigma = c(0.5,0.5/1),
                     prior_nu = c(1,0.1))
    arg <- list(T_anneal = 10000,       # Number of annealing steps
                M        = 1000,        # Number of annealing IS steps -> Number of particles in each annealing stage
                K        = 10,        # Number of Markov moves
                N        = 100,        # Number of particles in particle filter
                scaleCov = 0.1,        # Scale factor of covariance matrix for adaptive Markov move
                rho_corr = 0.999,
                seed = seed,
                family = family)

    return(list(data = data, priors = priors, arg = arg))
}
#' @export
rep_vector <- function(rep_x = rep_reduce(est.xdate, est.udate), vectorx){
    unlist(mapply(FUN = rep, x = vectorx, rep_x))
}

#' @export
reprow <- function(x,n){
    matrix(rep(x,each=n),nrow=n)
}





#' @export
restrict <- function(LB, UB){
    if (is.infinite(LB) && is.infinite(UB)){
        return( (function(x) ifelse(abs(x) > 0.01,x,sign(x) * 0.01 + x) ) )
    } else if (is.infinite(UB)){
        return( (function(x) exp(x)+LB) )
    } else if (is.infinite(LB)){
        return( (function(x) UB-exp(x)) )
    } else if (LB == UB) {
        return( return( (function(x) x + sign(x) * LB  ) ) )
    } else {
        return( (function(x) (LB + UB * exp(x))/(1+exp(x))) )
    }
}

#' @export
unrestrict <- function(LB, UB){
    if (is.infinite(LB) && is.infinite(UB)){
        return( (function(x) x) )
    } else if (is.infinite(UB)){
        return( (function(x) log(x-LB) ))
    } else if (is.infinite(LB)){
        return( (function(x) log(UB-x)) )
    } else if (LB == UB) {
        return( return( (function(x) x - sign(x) * LB  ) ) )
    } else {
        return( (function(x) log( (x - LB)/(UB - x)) ))
    }
}


#' @export
jacob <- function(LB,UB){
    if (is.infinite(LB) && is.infinite(LB)){
        return( (function(x) 1) )
    } else if (is.infinite(UB)){
        return( (function(x) x-LB) )
    } else if (is.infinite(LB)){
        return( (function(x) x-UB) )
    } else if (LB == UB) {
        return( (function(x) 1) )
    } else {
        return( (function(x) ((x-LB)*(UB-x))/(UB-LB)) )
    }
}

#' @export
prevMonth <- function(data.reduce.xdate, x.lag){
    last_date <- unlist(date_vec(data.reduce.xdate[1]))
    lag_date <- matrix(last_date, nrow = x.lag, ncol = 6, byrow = T)
    for (i in c(x.lag:1)){
        tmp <- lag_date[i,1] * 12 + lag_date[i,2]
        lag_date[i,2] <- (tmp + i - x.lag - 2) %% 12 + 1
        lag_date[i,1] <- (tmp + i - x.lag - 2) %/% 12
    }
    as.Date(paste(lag_date[,1], "-", lag_date[,2], "-", lag_date[,3], sep = ""))
}


#' Beta density polynomial weights
#'
#' @param param two-dimensional parameter vector \eqn{\theta}.
#' @param dayLag number of high-frequency lags.
#' @return (normalized) weights vector.
#' @description For a given set of parameters \eqn{\theta} and the number of high-frequency lags, returns weights implied by Beta density functional form.
#' @export beta_w
beta_w <- function(param,dayLag){
    weights <- sapply(c(1:dayLag), FUN = function(j) (j/(dayLag + 1))^(param[1] - 1) * (1 - j/(dayLag + 1))^(param[2] - 1))
    weights <- weights/sum(weights)
    weights
}

#' Restricted Beta density polynomial weights
#'
#' @param param one-dimensional parameter vector \eqn{\theta}.
#' @param dayLag number of high-frequency lags.
#' @return (normalized) weights vector.
#' @description For a given set of parameters \eqn{\theta} and the number of high-frequency lags, returns weights implied by Restricted Beta density functional form.
#' @export rbeta_w
rbeta_w <- function(param,dayLag){
    weights <- sapply(c(1:dayLag), FUN = function(j) (1 - j/(dayLag + 1))^(param[1] - 1))
    weights <- weights/sum(weights)
    weights
}

#' Exponential Almon polynomial weights
#'
#' @param param two-dimensional parameter vector \eqn{\theta}.
#' @param dayLag number of high-frequency lags.
#' @return (normalized) weights vector.
#' @description For a given set of parameters \eqn{\theta} and the number of high-frequency lags, returns weights implied by exponential Almon functional form.
#' @export expalmon_w
expalmon_w <- function(param,dayLag){
    grid <- seq(1,dayLag,length.out = dayLag)
    w <- exp(param[1]*grid+param[2]*grid^2)
    w <- w/sum(w)
    w
}

data_freq <- function(DateVec) {
    # Notes:
    #
    # Frequency   period   unit
    # yearly         1      1
    # semiannual     6      2
    # quarterly      3      2
    # monthly        1      2
    # biweekly       14     3
    # weekly         7      3
    # daily          1      3
    # hourly         1      4
    # minutely       1      5
    # secondly       1      6

    DateDiff <- as.matrix(diff(DateVec))

    # Check annual or lower frequency
    modeUse = mode_midasml(DateDiff[,1])$dataMode
    if(modeUse >= 1) {
        period <- modeUse
        unit <- 1
        return(list(period = period,unit = unit))
    }

    # Check monthly frequency, quarter = 3 months, semiannual = 6 months
    modeUse <- mode_midasml(DateDiff[,2])$dataMode
    mask <- isTRUE(modeUse < 0)
    modeUse[mask] <- modeUse[mask] + 12
    if(modeUse >= 1){
        period <- modeUse
        unit <- 2
        return(list(period = period,unit = unit))
    }

    # Check daily frequency, week = 7 days, biweekly = 14 days
    modeUse <- mode_midasml(DateDiff[,3])$dataMode
    mask <- isTRUE(modeUse < 0)
    modeUse[mask] <- modeUse[mask] +30
    if(modeUse >= 1){
        period <- modeUse
        unit <- 3
        return(list(period = period,unit = unit))
    }

    # Check hourly frequency

    modeUse <- mode_midasml(DateDiff[,4])$dataMode
    mask <- isTRUE(modeUse < 0)
    modeUse[mask] <- modeUse[mask] + 24
    if(modeUse >= 1){
        period <- modeUse
        unit <- 4
        return(list(period = period,unit = unit))
    }

    # Check minutely frequency
    modeUse <- mode_midasml(DateDiff[,5])$dataMode
    mask <- isTRUE(modeUse < 0)
    modeUse[mask] <- modeUse[mask] + 60
    if(modeUse >= 1){
        period <- modeUse
        unit <- 5
        return(list(period = period,unit = unit))
    }

    # Check secondly frequency
    elapse <- diff_time_mf(DateVec[2:dim(DateVec)[1],6],DateVec[1:dim(DateVec)[1]-1,6],origin = "1970-01-01",units = "secs")
    period <- mean(elapse)
    unit   <- 6
    return(list(period = period,unit = unit))
}

#' Compute mode of a vector
#'
#' @param data data vector.
#' @return a list of arguments.
#' @export mode_midasml
mode_midasml <- function(data) {
    nobs <- length(data)
    data <- sort(data)
    count <- 1
    countMax <- 1
    dataMode = data[1]
    for (t in 2:nobs){
        if(data[t]==data[t-1]){
            count <- count + 1
        }
        if(data[t]!=data[t-1]){
            if(count > countMax){
                countMax <- count
                dataMode <- data[t-1]
            }
            count <- 1
        }
    } # end of for
    if (count > countMax) {
        countMax <- count
        dataMode  <- data[nobs]
    }
    return(list(dataMode = dataMode, countMax = countMax))
} # end of mode

#' Transform date vector to numeric matrix
#'
#' @param s date vector.
#' @return numeric matrix of date vector.
#' @export date_vec
date_vec <- function(s) {
    mat <- matrix(0, nrow = length(s), ncol = 6 )
    a <- as.POSIXlt(as.Date(s, "1970-01-01"))
    mat[,1] <- a$year + 1900
    mat[,2] <- a$mon + 1
    mat[,3] <- a$mday
    mat[,4] <- as.numeric(strftime(a, "%u")) # Weekday as a decimal number (1–7, Monday is 1).
    mat[,5] <- as.numeric(strftime(a, "%U")) # Week of the year as decimal number (00–53) using Sunday as the first day 1 of the week
    mat[,6] <- a$sec

    list(mat)
}


#' Compute the number of lags
#'
#' @param x.lag number of high-frequency lags to construct in high-frequency time units.
#' @param period high-frequency data period.
#' @param unit units.
#' @return numeric value of the number of lags.
#' @export lag_num
lag_num <- function(x.lag,period,unit){
    if(is.numeric(x.lag)==T && is.atomic(x.lag)==T && length(x.lag) == 1L) {
        return(x.lag)
    }
    multiplier <- as.double(substr(x.lag, start = 1, stop = nchar(x.lag)-1))
    if (is.na(multiplier)) {
        stop('The description of lags cannot be recognized. The format should be 3m, 1q, etc')
    }
    #Convert multiplier to daily frequency (business days)
    ndaysPerYear <- 264
    ndaysPerQuarter <- 66
    ndaysPerMonth <- 22
    nhoursPerDay <- 8
    if(substr(x.lag, start = nchar(x.lag), stop = nchar(x.lag)) == 'y'){
        multiplier <- multiplier * ndaysPerYear
    }
    if(substr(x.lag, start = nchar(x.lag), stop = nchar(x.lag)) == 'q'){
        multiplier <- multiplier * ndaysPerQuarter
    }
    if(substr(x.lag, start = nchar(x.lag), stop = nchar(x.lag)) == 'm'){
        multiplier <- multiplier * ndaysPerMonth
    }
    if(substr(x.lag, start = nchar(x.lag), stop = nchar(x.lag)) == 'd'){
        multiplier <- multiplier * 1
    }
    if(substr(x.lag, start = nchar(x.lag), stop = nchar(x.lag)) == 'h'){
        multiplier <- multiplier / nhoursPerDay
    }
    if(substr(x.lag, start = nchar(x.lag), stop = nchar(x.lag)) == 's'){
        multiplier <- multiplier /  (nhoursPerDay*60*60)
    }
    if(unit == 1) {
        x.lag <- round(multiplier / (ndaysPerYear * period))
    }
    if(unit == 2) {
        x.lag <- round(multiplier / (ndaysPerMonth * period))
    }
    if(unit == 3) {
        x.lag <- round(multiplier / period)
    }
    if(unit == 4) {
        x.lag <- round(multiplier / (period / nhoursPerDay))
    }
    if(unit == 5) {
        x.lag <- round(multiplier / (period / nhoursPerDay / 60))
    }
    if(unit == 6) {
        x.lag <- round(multiplier / (period / nhoursPerDay / 60 / 60))
    }
    return(x.lag)
}

#' Computes the difference between two dates.
#'
#' @param time1 date 1.
#' @param time2 date 2.
#' @param origin date origin.
#' @param units units.
#' @return numeric value of difference in two dates.
#' @export diff_time_mf
diff_time_mf <- function(time1, time2, origin, units = c("auto", "secs", "mins", "hours", "days", "weeks")) {
    if (missing(origin)) {
        time1 <- as.POSIXct(time1)
        time2 <- as.POSIXct(time2)
    }
    else {
        time1 <- as.POSIXct(time1, origin = lubridate::origin)
        time2 <- as.POSIXct(time2, origin = lubridate::origin)
    }
    z <- unclass(time1) - unclass(time2)
    attr(z, "tzone") <- NULL
    units <- match.arg(units)
    if (units == "auto")
        units <- if (all(is.na(z)))
            "secs"
    else {
        zz <- min(abs(z), na.rm = TRUE)
        if (!is.finite(zz) || zz < 60)
            "secs"
        else if (zz < 3600)
            "mins"
        else if (zz < 86400)
            "hours"
        else "days"
    }
    switch(units, secs = .difftime(z, units = "secs"), mins = .difftime(z/60, units = "mins"),
           hours = .difftime(z/3600, units = "hours"),
           days = .difftime(z/86400, units = "days"),
           weeks = .difftime(z/(7 * 86400), units = "weeks"))
}

#' @export
get_mvc_weight <- function(sigmasq_sp, sigmasq_wti, cov_spwti, mean_sp, mean_wti, q = 10/252 ){
    # q is the daily target mean of the portfolio
    weight_out <- matrix(NA, nrow = length(sigmasq_sp), ncol = 2)
    mean_vec <- c(mean_sp, mean_wti)

    one <- matrix(1, ncol = 1, nrow = 2 )

    for (t in c(1:length(sigmasq_sp))){
        Sigma_inv <- solve( matrix(c(sigmasq_sp[t] , cov_spwti[t],
                                     cov_spwti[t], sigmasq_wti[t] ), ncol = 2) )
        A <- t(one) %*% Sigma_inv %*% one
        B <- t(one) %*% Sigma_inv %*% mean_vec
        C <- t(mean_vec) %*% Sigma_inv %*% mean_vec
        weight_out[t,] <- as.numeric((C - q * B) / (A * C - B^2)) * Sigma_inv %*% one +
            as.numeric((q * A - B) / (A * C - B^2)) * Sigma_inv %*% mean_vec
    }
    return(weight_out)
}

#' @export
logsumexp <- function(x) log(mean(exp(x - max(x)))) + max(x)
