#' Simulate DS MIDAS Copula object
#'
#' @description
#' Simulate DS MIDAS Copula object
#' @param time_start The date object of time simulation starts.
#' @param time_end The date object of time simulation ends.
#' @param vPars The parameter vector of simulation.
#' @param x.lag number of low-frequency lags to construct in high-frequency time units.
#' @param y.lag number of high-frequency lags to construct in low-frequency time units.
#' @param family The copula family.
#' @param iK The number of exogenous variables in x.
#' @param seed The seed number.
#' @return a list of a simulated DS MIDAS copula.
#' @examples
#' \dontrun{
#'
#' time_start = as.Date("2000-01-01")
#' time_end = as.Date("2010-01-01")
#' x.lag = 9
#' family = 1
#' polynomial = "rbeta_w"
#' seed = 0
#' iK = 2
#' vPars = c(1.00,  5.266415, -3.534793, 1, 1, -1, -2) # lambda0, B, sigma, gamma1, gamma2, theta1, theta2
#' family = 1
#' datagen <- sim.DSMIDASCopula(time_start = time_start, time_end = time_end,
#'                                 vPars = vPars, polynomial = polynomial,
#'                                 iK = 2, x.lag = 9, family = 1, seed = 0)
#' }
#' @export
sim.DSMIDASCopula <- function(time_start, time_end, vPars,
                                 polynomial = c("beta_w","rbeta_w","expalmon_w"),
                                 iK = 2, x.lag = 9, family = 1, seed = NULL, ...){
    set.seed(seed)
    tol <- 1e-10

    data.udate <- seq(time_start, time_end, by = 1)
    t_max <- length(data.udate)
    data.u <- matrix(NA, nrow = t_max, ncol = 2)

    data.reduce.xdate <- get_monthdata(data.x = NULL, data.xdate = data.udate)$data.xdate
    data.xdate <- c(prevMonth(data.reduce.xdate, x.lag), data.reduce.xdate)
    x_t_max <- length(data.xdate)

    #data.x <- matrix(gaussprocess(from = 0, to = 1, m = x_t_max * iK)$xt, ncol = iK)
    data.x <- sapply(1:iK, FUN = function(freq) sin( c(1:x_t_max) * 2 * pi / 60 / freq) )

    est.x <- matrix(NA, nrow = length(data.reduce.xdate), ncol = x.lag * ncol(data.x))

    for (t in seq(length(data.reduce.xdate))) {
        # take the one lag at time t
        loc <- min(which((data.xdate >= data.reduce.xdate[t] - tol) == TRUE))
        est.x[t,] = vec(data.x[(loc - 1):(loc - x.lag), ])
    }

    # initialize dynamics parameters and factors
    #vRestrictedParms = restrictParmsDSMIDAS(vPars, polynomial, family)
    Lambda0 = vPars[1]
    B = vPars[2]
    Sigma = sqrt(vPars[3])

    vUParms = vPars
    vUParms[2] = log(vPars[2]/(1 - vPars[2])) # B
    vUParms[3] = 0.5*log(vPars[3]) # sigma

    if (polynomial == "rbeta_w"){
        numMIDAS <- 2 # one paramter
        vMIDAS = vPars[4:(3+iK*numMIDAS)]
        vMIDAS_delta <- vPars[4:(3+iK)]
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]
        vMIDAS <- as.numeric(reprow(vMIDAS_delta, x.lag) * mapply(rbeta_w, param = vMIDAS_theta, dayLag = x.lag))
    }
    if (polynomial == "beta_w"){
        numMIDAS <- 3 # two paramters
        vMIDAS = vPars[4:(3+iK*numMIDAS)]
        vMIDAS_delta <- vPars[4:(3+iK)]
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]

        mMIDAS_theta <- matrix(vMIDAS_theta, nrow = iK, byrow = F)
        mMIDAS_theta <- alply(mMIDAS_theta, 1) # lapply(seq_len(ncol(mMIDAS_theta)), function(i) mMIDAS_theta[i,])
        vMIDAS <- as.numeric(reprow(vMIDAS_delta, x.lag) * mapply(beta_w, param = mMIDAS_theta, dayLag = x.lag))
    }
    if (polynomial == "expalmon_w"){
        numMIDAS <- 3 # two paramters
        vMIDAS = vPars[4:(3+iK*numMIDAS)]
        vMIDAS_delta <- vPars[4:(3+iK)]
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]

        mMIDAS_theta <- matrix(vMIDAS_theta, nrow = iK, byrow = F)
        mMIDAS_theta <- alply(mMIDAS_theta, 1) # lapply(seq_len(ncol(mMIDAS_theta)), function(i) mMIDAS_theta[i,])
        vMIDAS <- as.numeric(reprow(vMIDAS_delta, x.lag) * mapply(expalmon_w, param = mMIDAS_theta, dayLag = x.lag))
    }

    vLmean_t <- Lambda0 + est.x %*% vMIDAS # data.reduce.xdate
    vLmean_T <- rep_vector(rep_x = rep_reduce(data.reduce.xdate, data.udate),
                           vectorx = vLmean_t)
    if (family == 2){
        par2 = vPars[length(vPars)]
        vUParms[length(vPars)] = log(par2 - 2)
    } else {
        par2 = 0
    }

    # initial condition
    Kendalltau <- restrict(LB = -0.90, UB = 0.90)
    restricFun <- BicopParamRestrict(family)



    vThetas <- rep(0, t_max+1)
    vLambdas <- rep(0, t_max+1)
    vLambdas[1] = vLmean_T[1]
    vKendalls <- rep(0, t_max+1)

    vInnov <- rnorm(t_max)

    for (t in c(1:t_max)) {
        # compute the copula parameters based on the latent factors
        #t = t+1
        vKendalls[t] = Kendalltau(vLambdas[t])
        vTheta = restricFun(vKendalls[t] )
        vThetas[t] = vTheta

        # get the log pdf of the copula, and its gradient with respect to the copula parameters
        data.u[t,] <- BiCopSimMod(N = 1,family = family, par = vTheta, par2 = par2)

        # AR recursion
        vLambdas[t+1] = vLmean_T[t] * (1 - B) + B * vLambdas[t] + Sigma * vInnov[t]
    }

    return(list(data.u = data.u, data.udate = data.udate,
                data.x = data.x, data.xdate = data.xdate,
                est.x = est.x, data.reduce.xdate = data.reduce.xdate,
                t_max = t_max,
                vLambdas = vLambdas[1:t_max], vThetas = vThetas[1:t_max], vLmean_T = vLmean_T,
                vKendalls = vKendalls[1:t_max],
                Lambda0 = Lambda0, B = B, Sigma = Sigma,
                vPars = vPars, vUParms = vUParms, family = family,
                time_start = time_start, time_end = time_end))
}


#' Simulate DS Copula object
#'
#' @description
#' Simulate DS Copula object
#' @param time_start The date object of time simulation starts.
#' @param time_end The date object of time simulation ends.
#' @param vPars The parameter vector of simulation.
#' @param family The copula family.
#' @param seed The seed number.
#' @return a list of a simulated DS copula.
#' @examples
#' \dontrun{
#'
#' time_start = as.Date("2000-01-01")
#' time_end = as.Date("2010-01-01")
#' family = 1
#' seed = 0
#' vPars = c(1.00,  5.266415, -3.534793) # lambda0, B, sigma
#' datagen <- sim.DSCopula(time_start = time_start, time_end = time_end,
#'                                 vPars = vPars, family = 1, seed = 0)
#' }
#' @export
sim.DSCopula <- function(time_start, time_end, vPars,
                          family = 1, seed = NULL, ...){
    set.seed(seed)
    tol <- 1e-10

    data.udate <- seq(time_start, time_end, by = 1)
    t_max <- length(data.udate)
    data.u <- matrix(NA, nrow = t_max, ncol = 2)

    # initialize dynamics parameters and factors
    #vRestrictedParms = restrictParmsDS(vPars, family)
    Lambda0 = vPars[1]
    B = vPars[2]
    Sigma = sqrt(vPars[3])

    vUParms = vPars
    vUParms[2] = log(vPars[2]/(1 - vPars[2])) # B
    vUParms[3] = 0.5*log(vPars[3]) # sigma

    vLmean_T <- rep(Lambda0, length(data.udate))
    if (family == 2){
        par2 = vPars[length(vPars)]
        vUParms[length(vPars)] = log(par2 - 2)
    } else {
        par2 = 0
    }

    # initial condition
    Kendalltau <- restrict(LB = -0.90, UB = 0.90)
    restricFun <- BicopParamRestrict(family)

    vThetas <- rep(0, t_max+1)
    vLambdas <- rep(0, t_max+1)
    vKendalls <- rep(0, t_max+1)
    vLambdas[1] = vLmean_T[1]

    vInnov <- rnorm(t_max)

    for (t in c(1:t_max)) {
        # compute the copula parameters based on the latent factors
        #t = t+1
        vKendalls[t] = Kendalltau(vLambdas[t])
        vTheta = restricFun(vKendalls[t] )
        vThetas[t] = vTheta

        # get the log pdf of the copula, and its gradient with respect to the copula parameters
        data.u[t,] <- BiCopSimMod(N = 1,family = family, par = vTheta, par2 = par2)

        # AR recursion
        vLambdas[t+1] = vLmean_T[t] * (1 - B) + B * vLambdas[t] + Sigma * vInnov[t]
    }

    return(list(data.u = data.u, data.udate = data.udate,
                t_max = t_max,
                vLambdas = vLambdas[1:t_max], vThetas = vThetas[1:t_max], vLmean_T = vLmean_T,
                vKendalls = vKendalls[1:t_max],
                Lambda0 = Lambda0, B = B, Sigma = Sigma,
                vPars = vPars,
                vUParms = vUParms, family = family,
                time_start = time_start, time_end = time_end))
}

