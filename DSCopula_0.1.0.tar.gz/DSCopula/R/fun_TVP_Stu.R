#' @export
restrictParmsTVP_STu <- function(vPars, family){
    vRestrictedParms = vPars # lambda0, beta, sigma, nu
    #vRestrictedParms[1] = vPars[1]
    vRestrictedParms[2] = exp(vPars[2])/(1 + exp(vPars[2]))
    vRestrictedParms[3] = exp(vPars[3])
    vRestrictedParms[4] = exp(vPars[4])
    if (family == 2) {
        vRestrictedParms[5] <- 2 + exp(vPars[5])
    }
    return(vRestrictedParms)
}

#' @export
unrestrictParmsTVP_STu <- function(vPars, family){
    vuRestrictedParms = vPars # lambda0, beta, sigma, nu
    #vuRestrictedParms[1] = vPars[1]
    vuRestrictedParms[2] = log(vPars[2]/(1 - vPars[2]))
    vuRestrictedParms[3] = log(vPars[3])
    vuRestrictedParms[4] = log(vPars[4])

    if (family == 2) {
        vuRestrictedParms[5] <- log(vPars[5] - 2)
    }
    return(vuRestrictedParms)
}

#' @export
logpriorTVP_STu = function(vPars, family, priors){
    if (family == 2){
        res =   dnorm(vPars[1], priors$prior_Lambda0[1], sqrt(priors$prior_Lambda0[2]), log=TRUE) +
            dbeta(vPars[2], priors$prior_B[1], priors$prior_B[2], log=TRUE) +
            dgamma(vPars[3], shape = priors$prior_Sigma[1], rate = priors$prior_Sigma[2], log = TRUE) +
            dgamma(vPars[4], shape = priors$prior_Sigma[1], rate = priors$prior_Sigma[2], log = TRUE) +
            dgamma(vPars[5] - 2, shape = priors$prior_nu[1], rate = priors$prior_nu[2], log = TRUE)

    }
    return(res)
}


#' @export
logJacTVP_STu = function(vPars, family){
    res = log(1/vPars[4]) + log(1/vPars[3]) + log(1/vPars[2]+1/(1-vPars[2]))
    if (family == 2) res = res + log(1/ (vPars[5] - 2))
    return(res)
}



#' @export
TVP_STuCopula_pf <- function(un,uu,vPars, filterout = FALSE){
    family = arg$family
    est.u = data$est.u
    nn = nrow(data$est.u)
    N        = arg$N        # Number of particles in particle filter
    if (is.null(un)){
        un <- matrix(rnorm(N * nn * 2), nrow = N, ncol = nn * 2)
        uu <- matrix(runif(N * nn * 2), nrow = N, ncol = nn * 2)
    }

    Lambda0 = vPars[1]
    B       = vPars[2]
    Sigmasq = vPars[3]
    Sigmasq_nu = vPars[4]
    nu0 = ifelse(vPars[5] > 50, 49.5, vPars[5])

    if (family == 2) {
        densityFun <- function(u,v, pars, nu){
            nu <- ifelse(nu > 50, 50, nu)
            qu = qt(u, df = nu); qv = qt(v, nu); rhosq = pars^2; nud2 = 0.5 * nu;
            return( - log(2) + 2 * lgamma(nud2) - 2 * lgamma(nud2 + 0.5) -
                        (nud2 - 1) * log(nu) + (nud2 + 0.5) * log(1 - rhosq) +
                        (nud2 + 0.5) * ( log(nu + qu^2) + log(nu + qv^2) ) -
                        (nud2 + 1) * log( nu * ( 1 - rhosq) + (qu^2 + qv^2) - 2 * pars * qu * qv  ) )
        }
    }

    Kendalltau <- restrict(LB = -0.90, UB = 0.90)
    restricFun <- BicopParamRestrict(family)

    Lambda_prop  = un[,1]*sqrt(Sigmasq/(1-B^2))+Lambda0
    restrict_func_nu <- restrict(LB = 2, UB = 50)
    unrestrict_func_nu <- unrestrict(LB = 2, UB = 50)
    transform_nu <- un[,1+nn]*sqrt(Sigmasq_nu) + unrestrict_func_nu(nu0)
    Nu_prop  = restrict_func_nu(transform_nu)
    Nu_prop = ifelse(Nu_prop > 49.9, 49.9, Nu_prop)

    # Transform Lambda_prop to Theta domain
    th     = restricFun(Kendalltau(Lambda_prop))
    Lmean  = rep(NA,nn)
    Nu_mean  = rep(NA,nn)

    logw   = densityFun(est.u[1,1], est.u[1,2], th, Nu_prop)
    #ifelse(sum(is.na(logw)) > 0, print(c(1, th), sep = " "),0)
    w      = exp(logw-max(logw))
    llh    = log(mean(w))+max(logw)
    W      = w/sum(w)

    oLp <- order(Lambda_prop)
    wo     = W[oLp]
    ind    = findInterval(uu[,1],cumsum(c(0,wo)))
    indx   = oLp[ind]

    # indx    = findInterval(uu[,1],cumsum(c(0,W)))




    Lambda_sample = Lambda_prop[indx]
    Lmean[1]= mean(Lambda_sample)

    Nu_sample = Nu_prop[indx]
    Nu_mean[1]= mean(Nu_sample)

    for(t in 2:nn){
        Lambda_prop  = Lambda0 + B*(Lambda_sample - Lambda0) + un[,t] * sqrt(Sigmasq)
        transform_nu <- un[,t+nn]*sqrt(Sigmasq_nu) + unrestrict_func_nu(Nu_sample)
        Nu_prop  = restrict_func_nu(transform_nu)
        Nu_prop = ifelse(Nu_prop > 49.9, 49.9, Nu_prop)

        th     = restricFun(Kendalltau(Lambda_prop))
        logw   = densityFun(est.u[t,1], est.u[t,2], th, Nu_prop)
        #ifelse(sum(is.na(logw)) > 0, print(c(t, th), sep = " "),0)

        w      = exp(logw-max(logw))
        llh    = llh+log(mean(w))+max(logw)
        W      = w/sum(w)

        oLp <- order(Lambda_prop)
        wo     = W[oLp]
        ind    = findInterval(uu[,t],cumsum(c(0,wo)))
        indx   = oLp[ind]

        # indx    = findInterval(uu[,t],cumsum(c(0,W)))

        Lambda_sample = Lambda_prop[indx]
        Lmean[t]= mean(Lambda_sample)

        Nu_sample = Nu_prop[indx]
        Nu_mean[t]= mean(Nu_sample)

    }
    if (filterout){
        return(c(Lmean, Nu_mean))
    } else {
        return(llh)
    }

}

#' @export
TVP_STu_markov_move = function(un,uu,vPars,llh, psisq_current, cholV1){
    # un is Nxnn (Nxnn)
    # uu is Nxnn (Nxnn)
    # vPars is 1xn_params
    # llh is 1x1
    # us;
    acc = 0
    family = arg$family
    K = arg$K
    rho_corr = arg$rho_corr
    N = arg$N
    nn = nrow(data$est.u)
    scaleCov = arg$scaleCov
    n_params = 3 + 2*(family == 2)

    for(k in c(1:K)){
        # Update U
        u1_star          = un*rho_corr + sqrt(1-rho_corr^2)*matrix(rnorm(N*nn*2),nrow=N)
        u1_res_norm      = qnorm(uu)
        u1_res_norm_star = u1_res_norm*rho_corr + sqrt(1-rho_corr^2)*matrix(rnorm(N*nn*2),nrow=N)
        u1_res_star      = pnorm(u1_res_norm_star)

        # Transform the original parameters to -> [-Inf , Inf]
        params_normal = unrestrictParmsTVP_STu(vPars, family = family)
        # Using multivariate normal distribution as proposal function
        # Using scaleCov instead of scale as scale is a function in the base package
        R1 =( rnorm(n_params)*sqrt(2.38/n_params*scaleCov))%*%cholV1+params_normal

        # Convert parameter to original form
        vPars_star = restrictParmsTVP_STu(R1, family = family)

        lik_star    = TVP_STuCopula_pf(u1_star,u1_res_star,vPars_star, filterout = FALSE)

        # Calculate log-posterior for proposal samples

        lrat = psisq_current*(lik_star - llh)+
            logpriorTVP_STu(vPars_star, family, priors) - logpriorTVP_STu(vPars, family, priors) +
            logJacTVP_STu(vPars, family)-logJacTVP_STu(vPars_star, family)
        # Calculate acceptance probability
        r1 = lrat # in log scale

        # If accept the new proposal sample
        # Use this uniform random number to accept a proposal sample
        A1 = log(runif(1))
        if (A1 <= r1){
            vPars   = vPars_star
            llh = lik_star
            un  = u1_star
            uu  = u1_res_star
            acc = acc + 1
        }
    }
    res = list(un,uu,vPars,llh,acc)
    return(res)

}


#' @export
fit.TVP_STuCopula <- function(data, priors, arg){
    starttime = Sys.time()

    ## Define estimation parameters
    # T_anneal = 10000       # Number of annealing steps
    # M        = 500        # Number of annealing IS steps -> Number of particles in each annealing stage
    # K        = 10         # Number of Markov moves
    # N        = 100        # Number of particles in particle filter
    # scaleCov = 0.1        # Scale factor of covariance matrix for adaptive Markov move
    # rho_corr = 0.999
    T_anneal = arg$T_anneal       # Number of annealing steps
    M        = arg$M        # Number of annealing IS steps -> Number of particles in each annealing stage
    K        = arg$K         # Number of Markov moves
    N        = arg$N        # Number of particles in particle filter
    scaleCov = arg$scaleCov        # Scale factor of covariance matrix for adaptive Markov move
    rho_corr = arg$rho_corr

    seed = arg$seed
    set.seed(seed)

    family   = arg$family
    n_params = 3 + 2 * (family == 2)
    nn       = dim(data$est.u)[1] # Number of data points

    Lambda0_temp = rnorm(M, mean = priors$prior_Lambda0[1], sd = sqrt(priors$prior_Lambda0[2]))
    B_temp    = rbeta(M,shape1 = priors$prior_B[1], shape2 = priors$prior_B[2])
    Sigma_temp = rgamma(M, shape = priors$prior_Sigma[1], rate = priors$prior_Sigma[2] ) # Gamma prior
    Sigma_nu_temp = rgamma(M, shape = priors$prior_Sigma[1], rate = priors$prior_Sigma[2] ) # Gamma prior

    if (family == 2) {
        Nu_temp = 2 + rgamma(M, shape = priors$prior_nu[1], rate = priors$prior_nu[2])
        Nu_temp <- ifelse(Nu_temp > 50, 49.5, Nu_temp)
        priorp   = cbind(Lambda0_temp, B_temp, Sigma_temp, Sigma_nu_temp, Nu_temp)
    }
    params   = alply(priorp,1)

    u1       = alply(array(rnorm(N*M*nn*2),dim=c(M,N,nn*2)),1) # Random number for generating particles in particle filter
    u1_res   = alply(array(runif(N*M*nn*2),dim=c(M,N,nn*2)),1) # Random number for ancestor indexes

    # plan(multisession)
    llh_calc = future_mapply(TVP_STuCopula_pf, u1, u1_res, params, filterout = list(FALSE),
                             future.globals = structure(TRUE, add = c("data", "arg")))
    # for (i in c(1:M)) TVP_STuCopula_pf(un = u1[[i]], uu = u1_res[[i]], vPars = params[[i]])
    # TVP_STuCopula_pf(u1[[i]], u1_res[[i]], params[[i]])

    psisq   = ((0:T_anneal)/T_anneal)^3 # Specify an array of a_p -> each annealing level use 1 a_p
    log_llh = 0

    ESSall  = rep(NA,T_anneal)          # Store ESS in each level

    accept        = NULL
    t             = 2
    psisq_current = psisq[1]
    markov_idx    = 1
    timeall       = Sys.time()

    while (t<=T_anneal){

        # Reweighting the particles
        incw     = (psisq[t] - psisq_current)*llh_calc
        max_incw = max(incw)
        w        = exp(incw - max_incw)   # Numerical stability
        W        = w/sum(w)               # Calculate weights for current level
        ESS      = 1/sum(W^2)             # Estimate ESS for particles in the current level

        # Calculate covariance matrix of random walk proposal


        if (markov_idx < 5) V1 = diag(n_params) else {
            params_normal = t(sapply(params,unrestrictParmsTVP_STu, family = family))
            est           = apply(params_normal*W,2,sum)
            aux           = params_normal - matrix(est,ncol=ncol(params_normal),nrow=nrow(params_normal),byrow=TRUE)
            V1            = t(aux)%*%diag(W)%*%aux
        }
        cholV1 = chol(V1)


        # If a the current level, the ESS > 80% then skip Markov move -> move
        # to next annealing level
        while (ESS >= 0.8*M){
            t = t + 1
            if (t >= T_anneal+1){
                t        = T_anneal+1
                incw     = (psisq[t]-psisq_current)*llh_calc
                max_incw = max(incw)
                w        = exp(incw-max_incw)
                W        = w/sum(w)
                ESS      = 1/sum(W^2)
                ESSall[t-1] = ESS
                break
                } else{
                    incw     = (psisq[t]-psisq_current)*llh_calc
                    max_incw = max(incw)
                    w        = exp(incw-max_incw)
                    W        = w/sum(w)
                    ESS      = 1/sum(W^2)
                    ESSall[t-1] = ESS
                }
        }

        psisq_current = psisq[t]
        ESSall[t-1] = ESS
        log_llh     = log_llh + log(mean(w)) + max_incw

        # Should it be with rs_multinomial
        # Resampling for particles at the current annealing level
        indx     = sample(1:M,M,replace = TRUE,prob=W)

        params   = params[indx]
        llh_calc = llh_calc[indx]
        u1       = u1[indx]
        u1_res   = u1_res[indx]

        # llh_calc = alply(unname(llh_calc),1)
        # params   = unname(params)
        # u1       = unname(u1)
        # u1_res   = unname(u1_res)


        # Reset weights after resampling
        W = rep(1,M)/M
        #plan(multisession)

        time = Sys.time()
        RES  = future_mapply(TVP_STu_markov_move,u1,u1_res,params,llh_calc, list(psisq_current), list(cholV1), future.seed = TRUE,
                             future.globals = structure(TRUE, add = c("data", "arg", "priors")))
        cpu  = Sys.time()-time

        # for (i in c(1:M)) TVP_STu_markov_move( un = u1[[i]], uu = u1_res[[i]],
        #                                        vPars = params[[i]], llh = llh_calc[i],
        #                                        psisq_current = psisq_current, cholV1 = cholV1)


        u1       = RES[1,]
        u1_res   = RES[2,]
        params   = RES[3,]
        llh_calc = unname(unlist(RES[4,]))
        accept   = cbind(accept,unname(unlist(RES[5,])))

        print(paste('time=',round(cpu,2),', MarkovMove=',markov_idx,
                    ', MLLH=',round(log_llh,2),
                    ', acc%=',mean(unlist(RES[5,])/K),
                    ', progress=> ',round(t/T_anneal*100,1),'%',sep=''))
        print(colMeans(matrix(unlist(params), ncol = n_params, byrow = T)), sep=' ')
        #hist(llh_calc)
        #hist(matrix(unlist(params), ncol = n_params, byrow = T)[,3])
        # Delete the heavy matrix
        rm(RES); gc();

        markov_idx = markov_idx + 1
        t          = t+1
    }

    # post_res = future_mapply(TVP_STuCopula_pf, u1, u1_res, params, future.globals = structure(TRUE, add = c("data", "arg")))
    # post.llh = unlist(post_res)

    params <- matrix(unlist(params), ncol = n_params, byrow = T)
    parname <- c("Lambda0", "B", "Sigmasq", "Sigmasq_nu")
    if (family == 2) parname <- c(parname, "nu")
    colnames(params) <- parname
    endtime  = Sys.time()-starttime


    output <- list(
        n_params = n_params,
        params = params,
        log_llh = log_llh,
        llh_calc = llh_calc,
        data = data,
        priors = priors,
        arg = arg,
        esttime = endtime
    )
    class(output) <- c("DSCopula")

    return(output)

}

#' @export
filter.TVP_STuCopula <- function(TVP_STu_Obj){

    M        = TVP_STu_Obj$arg$M        # Number of annealing IS steps -> Number of particles in each annealing stage
    N        = TVP_STu_Obj$arg$N        # Number of particles in particle filter

    seed = TVP_STu_Obj$arg$seed
    set.seed(seed)

    family   = TVP_STu_Obj$arg$family
    n_params = 3 + 2*(family == 2)
    nn       = dim(TVP_STu_Obj$data$est.u)[1] # Number of data points

    params   = alply(TVP_STu_Obj$params,1)

    # u1       = alply(array(rnorm(N*M*nn*2),dim=c(M,N,nn*2)),1) # Random number for generating particles in particle filter
    # u1_res   = alply(array(runif(N*M*nn*2),dim=c(M,N,nn*2)),1) # Random number for ancestor indexes

    # plan(multisession)
    Lambda_filter = future_mapply(TVP_STuCopula_pf, un = list(NULL), uu = list(NULL),
                                  params, filterout = list(TRUE),
                             future.globals = structure(TRUE, add = c("data", "arg")),
                             future.seed = TRUE)
    LambdaM_filter = cbind(apply(Lambda_filter, 1,quantile,0.025),
                                   apply(Lambda_filter, 1,mean),
                                   apply(Lambda_filter, 1,quantile,0.975))
    # plot(LambdaM_filter[,2], type = "l")
    # lines(datagen$vLambdas, col = "red")
    # lines(LambdaM_filter[,1], col = "gray")
    # lines(LambdaM_filter[,3], col = "gray")

    Kendalltau <- restrict(LB = -0.90, UB = 0.90)
    restricFun <- BicopParamRestrict(family)

    Kendall_filter <- Kendalltau(Lambda_filter[1:nn,])
    KendallM_filter = cbind(apply(Kendall_filter, 1,quantile,0.025),
                           apply(Kendall_filter, 1,mean),
                           apply(Kendall_filter, 1,quantile,0.975))
    # plot(KendallM_filter[,2], type = "l")
    # lines(KendallM_filter[,1], col = "gray")
    # lines(KendallM_filter[,3], col = "gray")

    Theta_filter <- restricFun(Kendall_filter)
    ThetaM_filter = cbind(apply(Theta_filter, 1,quantile,0.025),
                            apply(Theta_filter, 1,mean),
                            apply(Theta_filter, 1,quantile,0.975))

    # plot(ThetaM_filter[,2], type = "l")
    # lines(ThetaM_filter[,1], col = "gray")
    # lines(ThetaM_filter[,3], col = "gray")
    Nu_filter <- Lambda_filter[(nn+1):(2*nn),]
    NuM_filter = cbind(apply(Nu_filter, 1,quantile,0.025),
                            apply(Nu_filter, 1,mean),
                            apply(Nu_filter, 1,quantile,0.975))

    return(list(Lambda_filter = Lambda_filter,
                LambdaM_filter = LambdaM_filter,
                Kendall_filter = Kendall_filter,
                KendallM_filter = KendallM_filter,
                Theta_filter = Theta_filter,
                ThetaM_filter = ThetaM_filter,
                Nu_filter = Nu_filter,
                NuM_filter = NuM_filter))
}
