#' @export
dcc.filter <- function(dvar, param){
    #Q_bar <- cov(dvar)
    t_max <- dim(dvar)[1]
    ndim <- dim(dvar)[2]

    Q_bar <- matrix(c(1,param[1],param[1],1), nrow = 2)
    b <- param[2]
    a <- param[3]


    Q_array <- array(NA, dim = c(t_max, ndim, ndim))
    R_array <- array(NA, dim = c(t_max, ndim * ndim))
    Q_array[1,,] <- Q_bar
    Q_star <- solve(diag(sqrt(diag(Q_array[1,,])), nrow = ndim, ncol = ndim))
    R_array[1,] <- vec(Q_star %*% Q_array[1,,] %*% Q_star)
    for (i in c(2:nrow(dvar))){
        Q_array[i,,] <- (1 - a - b) * Q_bar + a * dvar[i-1,] %*% t(dvar[i-1,]) + b * Q_array[i-1,,]
        Q_star <- solve(diag(sqrt(diag(Q_array[i,,])), nrow = ndim, ncol = ndim))
        R_array[i,] <- vec(Q_star %*% Q_array[i,,] %*% Q_star)
    }
    return(list(R_array = R_array,
                Q_array = Q_array))
}

#' @export
restrictParmsDCCC <- function(vPars, family){
    vRestrictedParms = vPars # lambda0, beta, sigma, nu
    vRestrictedParms[1] = (exp(vPars[1]) -1)/(1 + exp(vPars[1]))
    vRestrictedParms[2] = exp(vPars[2])/(1 + exp(vPars[2]))
    vRestrictedParms[3] = exp(vPars[3])/(1 + exp(vPars[3]))
    if (family == 2) {
        vRestrictedParms[4] <- 2 + exp(vPars[4])
    }
    return(vRestrictedParms)
}

#' @export
unrestrictParmsDCCC <- function(vPars, family){
    vuRestrictedParms = vPars # lambda0, beta, sigma, nu
    vuRestrictedParms[1] = log((vPars[1]+1)/(1 - vPars[1]))
    vuRestrictedParms[2] = log(vPars[2]/(1 - vPars[2]))
    vuRestrictedParms[3] = log(vPars[3]/(1 - vPars[3]))
    if (family == 2) {
        vuRestrictedParms[4] <- log(vPars[4] - 2)
    }
    return(vuRestrictedParms)
}

#' @export
logpriorDCCC = function(vPars, family, priors){
    if (family == 2){
        res =   dunif(vPars[1], min = -1, max = 1, log=TRUE) +
            dbeta(vPars[2], priors$prior_B[1], priors$prior_B[2], log=TRUE) +
            dbeta(vPars[3], priors$prior_B[2], priors$prior_B[1], log=TRUE) +
            dgamma(vPars[4] - 2, shape = priors$prior_nu[1], rate = priors$prior_nu[2], log = TRUE)

    } else{
        res = dunif(vPars[1], min = -1, max = 1, log=TRUE) +
            dbeta(vPars[2], priors$prior_B[1], priors$prior_B[2], log=TRUE) +
            dbeta(vPars[3], priors$prior_B[2], priors$prior_B[1], log=TRUE)
    }
    return(res)
}


#' @export
logJacDCCC = function(vPars, family){
    res = log(1/(1+vPars[1])+1/(1-vPars[1])) + log(1/vPars[2]+1/(1-vPars[2])) + log(1/vPars[3]+1/(1-vPars[3]))
    if (family == 2) res = res + log(1/ (vPars[4] - 2))
    return(res)
}

#' @export
DCCC_pf <- function(un,uu,vPars, filterout = FALSE){
    family = arg$family
    est.u = data$est.u
    nn = nrow(data$est.u)

    Lambda0 = vPars[1]
    B       = vPars[2]
    A = vPars[3]

    # if (family == 2) {
    #     nu = vPars[4]
    #     densityFun <- Bicoplogdensity(family, nu = nu)
    #     } else {
    #     densityFun <- Bicoplogdensity(family)
    #     }

    # Kendalltau <- restrict(LB = -0.90, UB = 0.90)
    # restricFun <- BicopParamRestrict(family)

    dLoglike = 0
    dvar <- qnorm(est.u)
    t_max <- dim(dvar)[1]
    ndim <- dim(dvar)[2]

    DCC <- dcc.filter(dvar = dvar, param = vPars)$R_array
    lf <- rep(0,t_max)  # bug fixed on 2013.08.18

    for( i in 1:t_max){
        R <- matrix(DCC[i,], ndim, ndim)
        invR <- solve(R)
        lf[i] <- - 0.5*(log(det(R)) + sum(dvar[i,]*crossprod(invR,dvar[i,])))
    }

    dLoglike <- ( sum(lf) - 0.5 * log(2*pi) * t_max * ndim - sum(dnorm(dvar, log = T)) )

    if (filterout){
        return(DCC[,2])
    } else {
        return(dLoglike)
    }

}

#' @export
DCCC_markov_move = function(un,uu,vPars,llh, psisq_current, cholV1){
    # un is Nxnn (Nxnn)
    # uu is Nxnn (Nxnn)
    # vPars is 1xn_params
    # llh is 1x1
    # us;
    acc = 0
    family = arg$family
    K = arg$K
    rho_corr = arg$rho_corr
    N = arg$N
    nn = nrow(data$est.u)
    scaleCov = arg$scaleCov
    n_params = 3 + (family == 2)

    for(k in c(1:K)){

        # Transform the original parameters to -> [-Inf , Inf]
        params_normal = unrestrictParmsDCCC(vPars, family = family)
        # Using multivariate normal distribution as proposal function
        # Using scaleCov instead of scale as scale is a function in the base package
        while (TRUE){
            R1 =( rnorm(n_params)*sqrt(2.38/n_params*scaleCov))%*%cholV1+params_normal
            # Convert parameter to original form
            vPars_star = restrictParmsDCCC(R1, family = family)
            if (abs(vPars_star[1]) < 1 & ((vPars_star[2] + vPars_star[3]) < 1)){
                break
            }
        }


        lik_star    = DCCC_pf(un = NULL,uu = NULL, vPars_star, filterout = FALSE)

        # Calculate log-posterior for proposal samples

        lrat = psisq_current*(lik_star - llh)+
            logpriorDCCC(vPars_star, family, priors) - logpriorDCCC(vPars, family, priors) +
            logJacDCCC(vPars, family)-logJacDCCC(vPars_star, family)
        # Calculate acceptance probability
        r1 = lrat # in log scale

        # If accept the new proposal sample
        # Use this uniform random number to accept a proposal sample
        A1 = log(runif(1))
        if (A1 <= r1){
            vPars   = vPars_star
            llh = lik_star
            un  = NULL
            uu  = NULL
            acc = acc + 1
        }
    }
    res = list(un,uu,vPars,llh,acc)
    return(res)

}


#' @export
fit.DCCC <- function(data, priors, arg){
    starttime = Sys.time()

    ## Define estimation parameters
    # T_anneal = 10000       # Number of annealing steps
    # M        = 500        # Number of annealing IS steps -> Number of particles in each annealing stage
    # K        = 10         # Number of Markov moves
    # N        = 100        # Number of particles in particle filter
    # scaleCov = 0.1        # Scale factor of covariance matrix for adaptive Markov move
    # rho_corr = 0.999
    T_anneal = arg$T_anneal       # Number of annealing steps
    M        = arg$M        # Number of annealing IS steps -> Number of particles in each annealing stage
    K        = arg$K         # Number of Markov moves
    N        = arg$N        # Number of particles in particle filter
    scaleCov = arg$scaleCov        # Scale factor of covariance matrix for adaptive Markov move
    rho_corr = arg$rho_corr

    seed = arg$seed
    set.seed(seed)

    family   = arg$family
    n_params = 3 + (family == 2)
    nn       = dim(data$est.u)[1] # Number of data points

    A_temp <- B_temp <- Lambda0_temp <- rep(0, M)
    # Lambda0_temp = rnorm(M, mean = priors$prior_Lambda0[1], sd = sqrt(priors$prior_Lambda0[2]))
    # B_temp    = rbeta(M,shape1 = priors$prior_B[1], shape2 = priors$prior_B[2])
    # A_temp    = rbeta(M,shape1 = priors$prior_B[2], shape2 = priors$prior_B[1])
    for (i in c(1:M)){
        while (TRUE){
            B_temp[i]    = rbeta(1,shape1 = priors$prior_B[1], shape2 = priors$prior_B[2])
            A_temp[i]    = rbeta(1,shape1 = priors$prior_B[2], shape2 = priors$prior_B[1])
            #Lambda0_temp[i] = rnorm(1, mean = priors$prior_Lambda0[1], sd = sqrt(priors$prior_Lambda0[2]))
            Lambda0_temp[i] = runif(1, min = -1, max = 1)
            if ( (A_temp[i] + B_temp[i] < 1) & (abs(Lambda0_temp[i]) < 1) ){
                break
            }
        }
    }


    if (family == 2) {
        Nu_temp = 2 + rgamma(M, shape = priors$prior_nu[1], rate = priors$prior_nu[2])
        priorp   = cbind(Lambda0_temp, B_temp, A_temp, Nu_temp)
    } else {
        priorp   = cbind(Lambda0_temp, B_temp, A_temp)
    }

    params   = alply(priorp,1)

    # plan(multisession)
    llh_calc = future_mapply(DCCC_pf, un = list(NULL), uu = list(NULL),
                             params, filterout = list(FALSE),
                             future.globals = structure(TRUE, add = c("data", "arg")))
    #for (i in c(1:M)) DCCC_pf(un = NULL, uu = NULL, vPars = params[[i]])

    psisq   = ((0:T_anneal)/T_anneal)^3 # Specify an array of a_p -> each annealing level use 1 a_p
    log_llh = 0

    ESSall  = rep(NA,T_anneal)          # Store ESS in each level

    accept        = NULL
    t             = 2
    psisq_current = psisq[1]
    markov_idx    = 1
    timeall       = Sys.time()

    while (t<=T_anneal){

        # Reweighting the particles
        incw     = (psisq[t] - psisq_current)*llh_calc
        max_incw = max(incw)
        w        = exp(incw - max_incw)   # Numerical stability
        W        = w/sum(w)               # Calculate weights for current level
        ESS      = 1/sum(W^2)             # Estimate ESS for particles in the current level

        # Calculate covariance matrix of random walk proposal


        if (markov_idx < 5) V1 = diag(n_params) else {
            params_normal = t(sapply(params,unrestrictParmsDCCC, family = family))
            est           = apply(params_normal*W,2,sum)
            aux           = params_normal - matrix(est,ncol=ncol(params_normal),nrow=nrow(params_normal),byrow=TRUE)
            V1            = t(aux)%*%diag(W)%*%aux
        }
        cholV1 = chol(V1)


        # If a the current level, the ESS > 80% then skip Markov move -> move
        # to next annealing level
        while (ESS >= 0.8*M){
            t = t + 1
            if (t >= T_anneal+1){
                t        = T_anneal+1
                incw     = (psisq[t]-psisq_current)*llh_calc
                max_incw = max(incw)
                w        = exp(incw-max_incw)
                W        = w/sum(w)
                ESS      = 1/sum(W^2)
                ESSall[t-1] = ESS
                break
                } else{
                    incw     = (psisq[t]-psisq_current)*llh_calc
                    max_incw = max(incw)
                    w        = exp(incw-max_incw)
                    W        = w/sum(w)
                    ESS      = 1/sum(W^2)
                    ESSall[t-1] = ESS
                }
        }

        psisq_current = psisq[t]
        ESSall[t-1] = ESS
        log_llh     = log_llh + log(mean(w)) + max_incw

        # Should it be with rs_multinomial
        # Resampling for particles at the current annealing level
        indx     = sample(1:M,M,replace = TRUE,prob=W)

        params   = params[indx]
        llh_calc = llh_calc[indx]


        # llh_calc = alply(unname(llh_calc),1)
        # params   = unname(params)
        # u1       = unname(u1)
        # u1_res   = unname(u1_res)


        # Reset weights after resampling
        W = rep(1,M)/M
        #plan(multisession)

        time = Sys.time()
        RES  = future_mapply(DCCC_markov_move,un = list(NULL),uu = list(NULL),
                             params,llh_calc, list(psisq_current), list(cholV1), future.seed = TRUE,
                             future.globals = structure(TRUE, add = c("data", "arg", "priors")))
        cpu  = Sys.time()-time

        # for (i in c(1:M)) DCCC_markov_move(NULL,NULL, vPars = params[[i]],
        #                                    llh = llh_calc[i], psisq_current = psisq_current, cholV1)

        params   = RES[3,]
        llh_calc = unname(unlist(RES[4,]))
        accept   = cbind(accept,unname(unlist(RES[5,])))

        print(paste('time=',round(cpu,2),', MarkovMove=',markov_idx,
                    ', MLLH=',round(log_llh,2),
                    ', acc%=',mean(unlist(RES[5,])/K),
                    ', progress=> ',round(t/T_anneal*100,1),'%',sep=''))
        print(colMeans(matrix(unlist(params), ncol = n_params, byrow = T)), sep=' ')
        #hist(llh_calc)
        #hist(matrix(unlist(params), ncol = n_params, byrow = T)[,3])
        # Delete the heavy matrix
        rm(RES); gc();

        markov_idx = markov_idx + 1
        t          = t+1
    }

    # post_res = future_mapply(DCCC_pf, u1, u1_res, params, future.globals = structure(TRUE, add = c("data", "arg")))
    # post.llh = unlist(post_res)

    params <- matrix(unlist(params), ncol = n_params, byrow = T)
    parname <- c("Lambda0", "B", "A")
    if (family == 2) parname <- c(parname, "nu")
    colnames(params) <- parname
    endtime  = Sys.time()-starttime


    output <- list(
        n_params = n_params,
        params = params,
        log_llh = log_llh,
        llh_calc = llh_calc,
        data = data,
        priors = priors,
        arg = arg,
        esttime = endtime
    )
    class(output) <- c("DCCC")

    return(output)

}

#' @export
filter.DCCC <- function(DCCC_Obj){

    M        = DCCC_Obj$arg$M        # Number of annealing IS steps -> Number of particles in each annealing stage
    N        = DCCC_Obj$arg$N        # Number of particles in particle filter

    seed = DCCC_Obj$arg$seed
    set.seed(seed)

    family   = DCCC_Obj$arg$family
    n_params = 3 + (family == 2)
    nn       = dim(DCCC_Obj$data$est.u)[1] # Number of data points

    params   = alply(DCCC_Obj$params,1)


    # plan(multisession)
    Lambda_filter = future_mapply(DCCC_pf, un = list(NULL), uu = list(NULL),
                                  params, filterout = list(TRUE),
                             future.globals = structure(TRUE, add = c("data", "arg")))
    LambdaM_filter = cbind(apply(Lambda_filter, 1,quantile,0.025),
                                   apply(Lambda_filter, 1,mean),
                                   apply(Lambda_filter, 1,quantile,0.975))
    # plot(LambdaM_filter[,2], type = "l")
    # lines(datagen$vLambdas, col = "red")
    # lines(LambdaM_filter[,1], col = "gray")
    # lines(LambdaM_filter[,3], col = "gray")

    Kendalltau <- restrict(LB = -0.90, UB = 0.90)
    restricFun <- BicopParamRestrict(family)

    Kendall_filter <- Kendalltau(Lambda_filter)
    KendallM_filter = cbind(apply(Kendall_filter, 1,quantile,0.025),
                           apply(Kendall_filter, 1,mean),
                           apply(Kendall_filter, 1,quantile,0.975))
    # plot(KendallM_filter[,2], type = "l")
    # lines(KendallM_filter[,1], col = "gray")
    # lines(KendallM_filter[,3], col = "gray")

    Theta_filter <- restricFun(Kendall_filter)
    ThetaM_filter = cbind(apply(Theta_filter, 1,quantile,0.025),
                            apply(Theta_filter, 1,mean),
                            apply(Theta_filter, 1,quantile,0.975))

    # plot(ThetaM_filter[,2], type = "l")
    # lines(ThetaM_filter[,1], col = "gray")
    # lines(ThetaM_filter[,3], col = "gray")


    return(list(Lambda_filter = Lambda_filter,
                LambdaM_filter = LambdaM_filter,
                Kendall_filter = Kendall_filter,
                KendallM_filter = KendallM_filter,
                Theta_filter = Theta_filter,
                ThetaM_filter = ThetaM_filter))
}
