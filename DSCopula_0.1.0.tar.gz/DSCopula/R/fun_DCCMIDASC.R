#' @export
dccmidas.filter <- function(dvar, param, vLambda_T){
    #Q_bar <- cov(dvar)
    t_max <- dim(dvar)[1]
    ndim <- dim(dvar)[2]


    b <- param[2]
    a <- param[3]

    Q_bar <- array(NA, dim = c(t_max, ndim, ndim))
    Q_array <- array(NA, dim = c(t_max, ndim, ndim))
    R_array <- array(NA, dim = c(t_max, ndim * ndim))



    Q_bar[,1,1] <- Q_bar[,2,2] <- 1
    Q_bar[,1,2] <- Q_bar[,2,1] <- vLambda_T
    Q_array[1,,] <- Q_bar[1,,]

    Q_star <- solve(diag(sqrt(diag(Q_array[1,,])), nrow = ndim, ncol = ndim))
    R_array[1,] <- vec(Q_star %*% Q_array[1,,] %*% Q_star)
    for (i in c(2:nrow(dvar))){
        Q_array[i,,] <- (1 - a - b) * Q_bar[i,,] + a * dvar[i-1,] %*% t(dvar[i-1,]) + b * Q_array[i-1,,]
        Q_star <- solve(diag(sqrt(diag(Q_array[i,,])), nrow = ndim, ncol = ndim))
        R_array[i,] <- vec(Q_star %*% Q_array[i,,] %*% Q_star)
    }
    return(list(R_array = R_array,
                Q_array = Q_array))
}

#' @export
restrictParmsDCCMIDASC <- function(vPars, priors, polynomial = "rbeta_w", family){
    vRestrictedParms = vPars # lambda0, beta, sigma, nu
    vRestrictedParms[1] = (exp(vPars[1]) -1)/(1 + exp(vPars[1]))
    vRestrictedParms[2] = exp(vPars[2])/(1 + exp(vPars[2]))
    vRestrictedParms[3] = exp(vPars[3])/(1 + exp(vPars[3]))
    if (polynomial == "rbeta_w"){
        numMIDAS <- 2 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vRestrictedParms[(4+iK):(3+iK*numMIDAS)] <- ( priors$prior_omega2[1] + priors$prior_omega2[2] * exp(vPars[(4+iK):(3+iK*numMIDAS)])) / (1 + exp(vPars[(4+iK):(3+iK*numMIDAS)]))
    }
    if (polynomial == "beta_w"){
        numMIDAS <- 3 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vRestrictedParms[(4+iK*1):(3+iK*2)] <- (priors$prior_omega1[1] + priors$prior_omega1[2] * exp(vPars[(4+iK):(3+iK*2)]))/ (1 + exp(vPars[(4+iK):(3+iK*2)]))
        vRestrictedParms[(4+iK*2):(3+iK*numMIDAS)] <- (priors$prior_omega2[1] + priors$prior_omega2[2] * exp(vPars[(4+iK*2):(3+iK*numMIDAS)])) / (1 + exp(vPars[(4+iK*2):(3+iK*numMIDAS)]))
    }
    if (polynomial == "expalmon_w"){
        numMIDAS <- 3 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vRestrictedParms[(4+iK*1):(3+iK*2)] <- (priors$prior_omega1[1] + priors$prior_omega1[2] * exp(vPars[(4+iK):(3+iK*2)]))/ (1 + exp(vPars[(4+iK):(3+iK*2)]))
        vRestrictedParms[(4+iK*2):(3+iK*numMIDAS)] <- (priors$prior_omega2[1] + priors$prior_omega2[2] * exp(vPars[(4+iK*2):(3+iK*numMIDAS)])) / (1 + exp(vPars[(4+iK*2):(3+iK*numMIDAS)]))
    }
    if (family == 2) {
        vRestrictedParms[length(vPars)] <- 2 + exp(vRestrictedParms[length(vPars)])
    }
    return(vRestrictedParms)
}

#' @export
unrestrictParmsDCCMIDASC <- function(vPars, priors, polynomial = "rbeta_w", family){
    vuRestrictedParms = vPars # lambda0, beta, sigma, nu
    vuRestrictedParms[1] = log((vPars[1]+1)/(1 - vPars[1]))
    vuRestrictedParms[2] = log(vPars[2]/(1 - vPars[2]))
    vuRestrictedParms[3] = log(vPars[3]/(1 - vPars[3]))
    if (family == 2) {
        vuRestrictedParms[length(vPars)] <- log(vPars[length(vPars)] - 2)
    }
    if (polynomial == "rbeta_w"){
        numMIDAS <- 2 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vuRestrictedParms[(4+iK):(3+iK*numMIDAS)] <- log( (vPars[(4+iK):(3+iK*numMIDAS)] - priors$prior_omega2[1]) / (priors$prior_omega2[2]  - vPars[(4+iK):(3+iK*numMIDAS)]) )
    }

    if (polynomial == "beta_w"){
        numMIDAS <- 3 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vuRestrictedParms[(4+iK):(3+iK*2)] <-  log( (vPars[(4+iK):(3+iK*2)] - priors$prior_omega1[1]) / (priors$prior_omega1[2] - vPars[(4+iK):(3+iK*2)]) )
        vuRestrictedParms[(4+iK*2):(3+iK*numMIDAS)] <-  log( (vPars[(4+iK*2):(3+iK*numMIDAS)] - priors$prior_omega2[1]) / (priors$prior_omega2[2] - vPars[(4+iK*2):(3+iK*numMIDAS)]) )
    }
    if (polynomial == "expalmon_w"){
        numMIDAS <- 3 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vuRestrictedParms[(4+iK):(3+iK*2)] <-  log( (vPars[(4+iK):(3+iK*2)] - priors$prior_omega1[1]) / (priors$prior_omega1[2] - vPars[(4+iK):(3+iK*2)]) )
        vuRestrictedParms[(4+iK*2):(3+iK*numMIDAS)] <-  log( (vPars[(4+iK*2):(3+iK*numMIDAS)] - priors$prior_omega2[1]) / (priors$prior_omega2[2] - vPars[(4+iK*2):(3+iK*numMIDAS)]) )
    }

    return(vuRestrictedParms)
}

#' @export
logpriorDCCMIDASC = function(vPars, priors, polynomial = "rbeta_w", family){
    res = dunif(vPars[1], min = -1, max = 1, log=TRUE) +
        dbeta(vPars[2], priors$prior_B[1], priors$prior_B[2], log=TRUE) +
        dbeta(vPars[3], priors$prior_B[2], priors$prior_B[1], log=TRUE)

    if (family == 2){
        res = res + dgamma(vPars[length(vPars)] - 2, shape = priors$prior_nu[1], rate = priors$prior_nu[2], log = TRUE)
    }

    if (polynomial == "rbeta_w"){
        numMIDAS <- 2 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        res =  res + sum(  dnorm(vPars[(4):(3+iK)], priors$prior_delta[1], sqrt(priors$prior_delta[2]), log=TRUE) ) +
            sum(  dunif(vPars[(4+iK):(3+iK*numMIDAS)], priors$prior_omega2[1], priors$prior_omega2[2], log=TRUE) )

    }

    if (polynomial == "beta_w"){
        numMIDAS <- 3 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]

        res =  res + sum(  dnorm(vPars[(4):(3+iK)], priors$prior_delta[1], sqrt(priors$prior_delta[2]), log=TRUE) ) +
            sum(  dunif(vMIDAS_theta[(1):(iK)], priors$prior_omega1[1], priors$prior_omega1[2], log=TRUE) ) +
            sum(  dunif(vMIDAS_theta[(iK+1):(2*iK)], priors$prior_omega2[1], priors$prior_omega2[2], log=TRUE) )

    }

    if (polynomial == "expalmon_w"){
        numMIDAS <- 3 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]

        res =  res + sum(  dnorm(vPars[(4):(3+iK)], priors$prior_delta[1], sqrt(priors$prior_delta[2]), log=TRUE) ) +
            sum(  dunif(vMIDAS_theta[(1):(iK)], priors$prior_omega1[1], priors$prior_omega1[2], log=TRUE) ) +
            sum(  dunif(vMIDAS_theta[(iK+1):(2*iK)], priors$prior_omega2[1], priors$prior_omega2[2], log=TRUE) )

    }

    return(res)
}


#' @export
logJacDCCMIDASC = function(vPars, priors, polynomial = "rbeta_w", family){
    res = log(1/(1+vPars[1])+1/(1-vPars[1])) + log(1/vPars[2]+1/(1-vPars[2])) + log(1/vPars[3]+1/(1-vPars[3]))
    if (family == 2) res = res + log(1/ (vPars[length(vPars)] - 2))
    if (polynomial == "rbeta_w"){
        numMIDAS <- 2 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]
        res =  res + sum(  sapply(1:iK, FUN = function(position) log( 1/(vMIDAS_theta[position]- priors$prior_omega2[1]) + 1/(priors$prior_omega2[2] - vMIDAS_theta[position]) ) )  )
    }
    if (polynomial == "beta_w"){
        numMIDAS <- 3 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vMIDAS_theta1 <- vPars[(4+iK):(3+iK*2)]
        vMIDAS_theta2 <- vPars[(4+iK*2):(3+iK*numMIDAS)]
        res =  res + sum(  sapply(1:iK, FUN = function(position) log( 1/(vMIDAS_theta1[position]-priors$prior_omega1[1]) + 1/(priors$prior_omega1[2] - vMIDAS_theta1[position]) ) )  )
        res =  res + sum(  sapply(1:iK, FUN = function(position) log( 1/(vMIDAS_theta2[position]-priors$prior_omega2[1]) + 1/(priors$prior_omega2[2] - vMIDAS_theta2[position]) ) )  )

    }
    if (polynomial == "expalmon_w"){
        numMIDAS <- 3 # one parameter
        iK = (length(vPars) - 3) %/% numMIDAS
        vMIDAS_theta1 <- vPars[(4+iK):(3+iK*2)]
        vMIDAS_theta2 <- vPars[(4+iK*2):(3+iK*numMIDAS)]
        res =  res + sum(  sapply(1:iK, FUN = function(position) log( 1/(vMIDAS_theta1[position]-priors$prior_omega1[1]) + 1/(priors$prior_omega1[2] - vMIDAS_theta1[position]) ) )  )
        res =  res + sum(  sapply(1:iK, FUN = function(position) log( 1/(vMIDAS_theta2[position]-priors$prior_omega2[1]) + 1/(priors$prior_omega2[2] - vMIDAS_theta2[position]) ) )  )

    }
    return(res)
}

#' @export
DCCMIDASC_pf <- function(un,uu,vPars, filterout = FALSE){
    family = arg$family
    est.u = data$est.u
    est.x = data$est.x
    est.udate = data$est.udate
    est.xdate = data$est.xdate
    nn = nrow(data$est.u)
    N        = arg$N        # Number of particles in particle filter
    polynomial = arg$polynomial
    iK = arg$iK
    x.lag = arg$x.lag

    Lambda0 = vPars[1]
    B       = vPars[2]
    A = vPars[3]

    # if (family == 2) {
    #     nu = vPars[4]
    #     densityFun <- Bicoplogdensity(family, nu = nu)
    #     } else {
    #     densityFun <- Bicoplogdensity(family)
    #     }

    # Kendalltau <- restrict(LB = -0.90, UB = 0.90)
    # restricFun <- BicopParamRestrict(family)

    if (polynomial == "rbeta_w"){
        numMIDAS <- 2 # one paramter
        vMIDAS = vPars[4:(3+iK*numMIDAS)]
        vMIDAS_delta <- vPars[4:(3+iK)]
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]
        vMIDAS <- as.numeric(reprow(vMIDAS_delta, x.lag) * mapply(rbeta_w, param = vMIDAS_theta, dayLag = x.lag))
    }
    if (polynomial == "beta_w"){
        numMIDAS <- 3 # two paramters
        vMIDAS = vPars[4:(3+iK*numMIDAS)]
        vMIDAS_delta <- vPars[4:(3+iK)]
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]
        mMIDAS_theta <- matrix(vMIDAS_theta, nrow = iK, byrow = F)
        mMIDAS_theta <- alply(mMIDAS_theta, 1) # lapply(seq_len(ncol(mMIDAS_theta)), function(i) mMIDAS_theta[i,])
        vMIDAS <- as.numeric(reprow(vMIDAS_delta, x.lag) * mapply(beta_w, param = mMIDAS_theta, dayLag = x.lag))
    }
    if (polynomial == "expalmon_w"){
        numMIDAS <- 3 # two paramters
        vMIDAS = vPars[4:(3+iK*numMIDAS)]
        vMIDAS_delta <- vPars[4:(3+iK)]
        vMIDAS_theta <- vPars[(4+iK):(3+iK*numMIDAS)]
        mMIDAS_theta <- matrix(vMIDAS_theta, nrow = iK, byrow = F)
        mMIDAS_theta <- alply(mMIDAS_theta, 1) # lapply(seq_len(ncol(mMIDAS_theta)), function(i) mMIDAS_theta[i,])
        vMIDAS <- as.numeric(reprow(vMIDAS_delta, x.lag) * mapply(expalmon_w, param = mMIDAS_theta, dayLag = x.lag))
    }

    Lambda_tau = Lambda0 + est.x %*% vMIDAS # data.reduce.xdate
    if (any(abs(Lambda_tau) > 1)) {
        return(-1e10)
    }

    vLambda_T <- rep_vector(rep_x = rep_reduce(est.xdate, est.udate),
                            vectorx = Lambda_tau)

    # Filtering matrix
    Lambda_sample <- matrix(NA, ncol = nn, nrow = N)
    Lmean  = rep(NA, nn)

    dLoglike = 0
    dvar <- qnorm(est.u)
    t_max <- dim(dvar)[1]
    ndim <- dim(dvar)[2]

    DCC <- dccmidas.filter(dvar = dvar, param = vPars, vLambda_T = vLambda_T)$R_array
    lf <- rep(0,t_max)  # bug fixed on 2013.08.18

    for( i in 1:t_max){
        R <- matrix(DCC[i,], ndim, ndim)
        invR <- solve(R)
        lf[i] <- - 0.5*(log(det(R)) + sum(dvar[i,]*crossprod(invR,dvar[i,])))
    }

    dLoglike <- ( sum(lf) - 0.5 * log(2*pi) * t_max * ndim - sum(dnorm(dvar, log = T)) )

    if (filterout){
        return(c(DCC[,2], vLambda_T))
    } else {
        return(dLoglike)
    }

}

#' @export
DCCMIDASC_markov_move = function(un,uu,vPars,llh, psisq_current, cholV1){
    # un is Nxnn (Nxnn)
    # uu is Nxnn (Nxnn)
    # vPars is 1xn_params
    # llh is 1x1
    # us;
    acc = 0
    family = arg$family
    K = arg$K
    rho_corr = arg$rho_corr
    N = arg$N
    nn = nrow(data$est.u)
    scaleCov = arg$scaleCov
    polynomial = arg$polynomial
    iK = arg$iK
    n_params = 3 + (family == 2) + ifelse(polynomial == "rbeta_w", iK * 2, iK * 3)

    for(k in c(1:K)){

        # Transform the original parameters to -> [-Inf , Inf]
        params_normal = unrestrictParmsDCCMIDASC(vPars, priors = priors, polynomial = polynomial, family = family)
        # Using multivariate normal distribution as proposal function
        # Using scaleCov instead of scale as scale is a function in the base package
        while (TRUE){
            R1 =( rnorm(n_params)*sqrt(2.38/n_params*scaleCov))%*%cholV1+params_normal
            # Convert parameter to original form
            vPars_star = restrictParmsDCCMIDASC(R1, priors = priors, polynomial = polynomial, family = family)
            if (((vPars_star[2] + vPars_star[3]) < 1)){
                break
            }
        }


        lik_star    = DCCMIDASC_pf(un = NULL,uu = NULL, vPars_star, filterout = FALSE)

        # Calculate log-posterior for proposal samples

        lrat = psisq_current*(lik_star - llh)+
            logpriorDCCMIDASC(vPars_star, priors, polynomial, family) - logpriorDCCMIDASC(vPars,priors, polynomial, family) +
            logJacDCCMIDASC(vPars,priors, polynomial, family)-logJacDCCMIDASC(vPars_star, priors, polynomial, family)
        # Calculate acceptance probability
        r1 = lrat # in log scale

        # If accept the new proposal sample
        # Use this uniform random number to accept a proposal sample
        A1 = log(runif(1))
        if (A1 <= r1){
            vPars   = vPars_star
            llh = lik_star
            un  = NULL
            uu  = NULL
            acc = acc + 1
        }
    }
    res = list(un,uu,vPars,llh,acc)
    return(res)

}


#' @export
fit.DCCMIDASC <- function(data, priors, arg){
    starttime = Sys.time()

    ## Define estimation parameters
    # T_anneal = 10000       # Number of annealing steps
    # M        = 500        # Number of annealing IS steps -> Number of particles in each annealing stage
    # K        = 10         # Number of Markov moves
    # N        = 100        # Number of particles in particle filter
    # scaleCov = 0.1        # Scale factor of covariance matrix for adaptive Markov move
    # rho_corr = 0.999
    T_anneal = arg$T_anneal       # Number of annealing steps
    M        = arg$M        # Number of annealing IS steps -> Number of particles in each annealing stage
    K        = arg$K         # Number of Markov moves
    N        = arg$N        # Number of particles in particle filter
    scaleCov = arg$scaleCov        # Scale factor of covariance matrix for adaptive Markov move
    rho_corr = arg$rho_corr

    seed = arg$seed
    set.seed(seed)

    family = arg$family
    polynomial = arg$polynomial
    iK = arg$iK
    x.lag = arg$x.lag

    n_params = 3 + (family == 2) + ifelse(polynomial == "rbeta_w", iK * 2, iK * 3)
    nn       = dim(data$est.u)[1] # Number of data points

    A_temp <- B_temp <- Lambda0_temp <- rep(0, M)
    # Lambda0_temp = rnorm(M, mean = priors$prior_Lambda0[1], sd = sqrt(priors$prior_Lambda0[2]))
    # B_temp    = rbeta(M,shape1 = priors$prior_B[1], shape2 = priors$prior_B[2])
    # A_temp    = rbeta(M,shape1 = priors$prior_B[2], shape2 = priors$prior_B[1])
    for (i in c(1:M)){
        while (TRUE){
            B_temp[i]    = rbeta(1,shape1 = priors$prior_B[1], shape2 = priors$prior_B[2])
            A_temp[i]    = rbeta(1,shape1 = priors$prior_B[2], shape2 = priors$prior_B[1])
            #Lambda0_temp[i] = rnorm(1, mean = priors$prior_Lambda0[1], sd = sqrt(priors$prior_Lambda0[2]))
            Lambda0_temp[i] = runif(1, min = -1, max = 1)
            if ( (A_temp[i] + B_temp[i] < 1) ){
                break
            }
        }
    }

    Delta_temp = matrix( rnorm(iK * M, mean = priors$prior_delta[1], sd = priors$prior_delta[2]),
                         ncol = iK, dimnames = list(NULL, paste("Delta", 1:iK, sep = "") ) )
    if (polynomial == "rbeta_w") {
        Omega_temp = matrix( runif( iK * M, min = priors$prior_omega2[1], max = priors$prior_omega2[2]),
                             ncol = iK, dimnames = list(NULL, paste("Omega", 1:iK, sep = "") ) )

        priorp   = cbind(Lambda0_temp, B_temp, A_temp, Delta_temp, Omega_temp)
    } else {
        Omega1_temp = matrix( runif( iK * M, min = priors$prior_omega1[1], max = priors$prior_omega1[2]),
                              ncol = iK, dimnames = list(NULL, paste("Omega1", 1:iK, sep = "") ) )
        Omega2_temp = matrix( runif( iK * M, min = priors$prior_omega2[1], max = priors$prior_omega2[2]),
                              ncol = iK, dimnames = list(NULL, paste("Omega2", 1:iK, sep = "") ) )
        priorp   = cbind(Lambda0_temp, B_temp, A_temp, Delta_temp, Omega1_temp, Omega2_temp)
    }

    if (family == 2) {
        Nu_temp = 2 + rgamma(M, shape = priors$prior_nu[1], rate = priors$prior_nu[2])
        priorp   = cbind(priorp, Nu_temp)
    }

    params   = alply(priorp,1)

    # plan(multisession)
    llh_calc = future_mapply(DCCMIDASC_pf, un = list(NULL), uu = list(NULL),
                             params, filterout = list(FALSE),
                             future.globals = structure(TRUE, add = c("data", "arg")))
    #for (i in c(1:M)) DCCMIDASC_pf(un = NULL, uu = NULL, vPars = params[[i]])

    psisq   = ((0:T_anneal)/T_anneal)^3 # Specify an array of a_p -> each annealing level use 1 a_p
    log_llh = 0

    ESSall  = rep(NA,T_anneal)          # Store ESS in each level

    accept        = NULL
    t             = 2
    psisq_current = psisq[1]
    markov_idx    = 1
    timeall       = Sys.time()

    while (t<=T_anneal){

        # Reweighting the particles
        incw     = (psisq[t] - psisq_current)*llh_calc
        max_incw = max(incw)
        w        = exp(incw - max_incw)   # Numerical stability
        W        = w/sum(w)               # Calculate weights for current level
        ESS      = 1/sum(W^2)             # Estimate ESS for particles in the current level

        # Calculate covariance matrix of random walk proposal


        if (markov_idx < 5) V1 = diag(n_params) else {
            params_normal = t(sapply(params,unrestrictParmsDCCMIDASC, priors = priors, polynomial = polynomial, family = family))
            est           = apply(params_normal*W,2,sum)
            aux           = params_normal - matrix(est,ncol=ncol(params_normal),nrow=nrow(params_normal),byrow=TRUE)
            V1            = t(aux)%*%diag(W)%*%aux
        }
        cholV1 = chol(V1)


        # If a the current level, the ESS > 80% then skip Markov move -> move
        # to next annealing level
        while (ESS >= 0.8*M){
            t = t + 1
            if (t >= T_anneal+1){
                t        = T_anneal+1
                incw     = (psisq[t]-psisq_current)*llh_calc
                max_incw = max(incw)
                w        = exp(incw-max_incw)
                W        = w/sum(w)
                ESS      = 1/sum(W^2)
                ESSall[t-1] = ESS
                break
            } else{
                incw     = (psisq[t]-psisq_current)*llh_calc
                max_incw = max(incw)
                w        = exp(incw-max_incw)
                W        = w/sum(w)
                ESS      = 1/sum(W^2)
                ESSall[t-1] = ESS
            }
        }

        psisq_current = psisq[t]
        ESSall[t-1] = ESS
        log_llh     = log_llh + log(mean(w)) + max_incw

        # Should it be with rs_multinomial
        # Resampling for particles at the current annealing level
        indx     = sample(1:M,M,replace = TRUE,prob=W)

        params   = params[indx]
        llh_calc = llh_calc[indx]


        # llh_calc = alply(unname(llh_calc),1)
        # params   = unname(params)
        # u1       = unname(u1)
        # u1_res   = unname(u1_res)


        # Reset weights after resampling
        W = rep(1,M)/M
        #plan(multisession)

        time = Sys.time()
        RES  = future_mapply(DCCMIDASC_markov_move,un = list(NULL),uu = list(NULL),
                             params,llh_calc, list(psisq_current), list(cholV1), future.seed = TRUE,
                             future.globals = structure(TRUE, add = c("data", "arg", "priors")))
        cpu  = Sys.time()-time

        # for (i in c(1:M)) DCCMIDASC_markov_move(NULL,NULL, vPars = params[[i]],
        #                                    llh = llh_calc[i], psisq_current = psisq_current, cholV1)

        params   = RES[3,]
        llh_calc = unname(unlist(RES[4,]))
        accept   = cbind(accept,unname(unlist(RES[5,])))

        print(paste('time=',round(cpu,2),', MarkovMove=',markov_idx,
                    ', MLLH=',round(log_llh,2),
                    ', acc%=',mean(unlist(RES[5,])/K),
                    ', progress=> ',round(t/T_anneal*100,1),'%',sep=''))
        print(colMeans(matrix(unlist(params), ncol = n_params, byrow = T)), sep=' ')
        #hist(llh_calc)
        #hist(matrix(unlist(params), ncol = n_params, byrow = T)[,3])
        # Delete the heavy matrix
        rm(RES); gc();

        markov_idx = markov_idx + 1
        t          = t+1
    }

    # post_res = future_mapply(DCCMIDASC_pf, u1, u1_res, params, future.globals = structure(TRUE, add = c("data", "arg")))
    # post.llh = unlist(post_res)

    params <- matrix(unlist(params), ncol = n_params, byrow = T)
    parname <- c("Lambda0", "B", "A",  paste("Delta", 1:iK, sep = "") )
    if (polynomial == "rbeta_w") {
        parname <- c(parname, paste("Omega", 1:iK, sep = ""))
    } else {
        parname <- c(parname, paste("Omega1", 1:iK, sep = ""))
        parname <- c(parname, paste("Omega2", 1:iK, sep = ""))
    }
    if (family == 2) parname <- c(parname, "nu")
    colnames(params) <- parname
    endtime  = Sys.time()-starttime


    output <- list(
        n_params = n_params,
        params = params,
        log_llh = log_llh,
        llh_calc = llh_calc,
        data = data,
        priors = priors,
        arg = arg,
        esttime = endtime
    )
    class(output) <- c("DCCMIDASC")

    return(output)

}

#' @export
filter.DCCMIDASC <- function(DCCMIDASC_Obj){

    M        = DCCMIDASC_Obj$arg$M        # Number of annealing IS steps -> Number of particles in each annealing stage
    N        = DCCMIDASC_Obj$arg$N        # Number of particles in particle filter

    seed = DCCMIDASC_Obj$arg$seed
    set.seed(seed)

    family   = DCCMIDASC_Obj$arg$family
    n_params = 3 + (family == 2) + ifelse(polynomial == "rbeta_w", iK * 2, iK * 3)
    nn       = dim(DCCMIDASC_Obj$data$est.u)[1] # Number of data points

    params   = alply(DCCMIDASC_Obj$params,1)


    # plan(multisession)
    Lambda_filter = future_mapply(DCCMIDASC_pf, un = list(NULL), uu = list(NULL),
                                  params, filterout = list(TRUE),
                                  future.globals = structure(TRUE, add = c("data", "arg")))
    Total_lambda = Lambda_filter[1:nn,]
    Longterm_lambda = Lambda_filter[(nn+1):(2*nn),]

    LambdaM_filter = cbind(apply(Total_lambda, 1,quantile,0.025),
                           apply(Total_lambda, 1,mean),
                           apply(Total_lambda, 1,quantile,0.975))
    LTLambda = cbind(apply(Longterm_lambda, 1,quantile,0.025),
                     apply(Longterm_lambda, 1,mean),
                     apply(Longterm_lambda, 1,quantile,0.975))
    # plot(LambdaM_filter[,2], type = "l")
    # lines(datagen$vLambdas, col = "red")
    # lines(LambdaM_filter[,1], col = "gray")
    # lines(LambdaM_filter[,3], col = "gray")

    Kendalltau <- restrict(LB = -0.90, UB = 0.90)
    restricFun <- BicopParamRestrict(family)

    Kendall_filter <- Kendalltau(Total_lambda)
    KendallM_filter = cbind(apply(Kendall_filter, 1,quantile,0.025),
                            apply(Kendall_filter, 1,mean),
                            apply(Kendall_filter, 1,quantile,0.975))
    LTKendall = Kendalltau(LTLambda)

    # plot(KendallM_filter[,2], type = "l")
    # lines(KendallM_filter[,1], col = "gray")
    # lines(KendallM_filter[,3], col = "gray")

    Theta_filter <- matrix(restricFun(Kendall_filter), nrow = nn)
    ThetaM_filter = cbind(apply(Theta_filter, 1,quantile,0.025),
                          apply(Theta_filter, 1,mean),
                          apply(Theta_filter, 1,quantile,0.975))
    LTTheta = matrix(restricFun(LTKendall), nrow = nn)

    # plot(ThetaM_filter[,2], type = "l")
    # lines(ThetaM_filter[,1], col = "gray")
    # lines(ThetaM_filter[,3], col = "gray")


    return(list(Lambda_filter = Total_lambda,
                LambdaM_filter = LambdaM_filter,
                LTLambda = LTLambda,
                Kendall_filter = Kendall_filter,
                KendallM_filter = KendallM_filter,
                LTKendall = LTKendall,
                Theta_filter = Theta_filter,
                ThetaM_filter = ThetaM_filter,
                LTTheta = LTTheta))
}
