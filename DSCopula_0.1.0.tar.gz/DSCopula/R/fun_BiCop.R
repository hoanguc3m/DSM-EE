#' @export
Bicoplogdensity <- function(family, nu = NULL){
    if (family == 1) {
        return(function(u,v, pars) {
            #log(BiCopPDF(u1 = u, u2 = v, family = 1, par = pars) )
            qu = qnorm(u); qv = qnorm(v); rhosq = pars^2;
            return(-0.5 * log(1 - rhosq) - 0.5 * ( rhosq * (qu^2 + qv^2) - 2 * pars * qu * qv  ) / (1 - rhosq) )
        }
        )
    }

    if (family == 2) {
        # if (nu < 50) {

        return(function(u,v, pars) {
            #log(BiCopPDF(u1 = u, u2 = v, family = 2, par = pars, par2 = 0) )
                qu = qt(u, df = nu); qv = qt(v, nu); rhosq = pars^2; nud2 = 0.5 * nu;
                return( - log(2) + 2 * lgamma(nud2) - 2 * lgamma(nud2 + 0.5) -
                            (nud2 - 1) * log(nu) + (nud2 + 0.5) * log(1 - rhosq) +
                            (nud2 + 0.5) * ( log(nu + qu^2) + log(nu + qv^2) ) -
                            (nud2 + 1) * log( nu * ( 1 - rhosq) + (qu^2 + qv^2) - 2 * pars * qu * qv  ) )


            })
        # } else {
        #     return(    Bicoplogdensity(family = 1))
        # }


    }

    if (family == 3) {
        return(function(u,v, pars) {
            #log(BiCopPDF(u1 = u, u2 = v, family = 3, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 13, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 23, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 33, par = pars) )
        # if (pars > 0){
        #     density <- 0.5 * (  log(pars + 1) - (pars + 1) * (log(u) + log(v)) - (1/ pars + 2) * log( u^(-pars) + v^(-pars) - 1 )) +
        #         0.5 * (  log(pars + 1) - (pars + 1) * (log(1-u) + log(1-v)) - (1/ pars + 2) * log( (1-u)^(-pars) + (1-v)^(-pars) - 1 ))
        # } else {
        #     density <- 0.5 * (  log(-pars + 1) - (-pars + 1) * (log(1-u) + log(v)) - (-1/ pars + 2) * log( (1-u)^(pars) + v^(pars) - 1 )) +
        #         0.5 * (  log(-pars + 1) - (-pars + 1) * (log(u) + log(1-v)) - (-1/ pars + 2) * log( (u)^(pars) + (1-v)^(pars) - 1 ))
        # }
        #     return(density)
        # }

            apars = abs(pars)
            density <- ifelse(pars > 0,
                0.5 * (  log(apars + 1) - (apars + 1) * (log(u) + log(v)) - (1/ apars + 2) * log( u^(-apars) + v^(-apars) - 1 )) +
                    0.5 * (  log(apars + 1) - (apars + 1) * (log(1-u) + log(1-v)) - (1/ apars + 2) * log( (1-u)^(-apars) + (1-v)^(-apars) - 1 )),
                0.5 * (  log(apars + 1) - (apars + 1) * (log(1-u) + log(v)) - (1/ apars + 2) * log( (1-u)^(-apars) + v^(-apars) - 1 )) +
                    0.5 * (  log(apars + 1) - (apars + 1) * (log(u) + log(1-v)) - (1/ apars + 2) * log( (u)^(-apars) + (1-v)^(-apars) - 1 ))
            )
            return(density)
        }

        )
    }

    if (family == 4) {
        return(function(u,v, pars) {
            #log(BiCopPDF(u1 = u, u2 = v, family = 4, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 14, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 24, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 34, par = pars) )
            # if (pars > 0){
            #     x = - log(u); y = - log(v);
            #     xn = - log(1-u); yn = - log(1-v);
            #
            #     density <- 0.5 * ( -(x^pars + y^pars)^(1/pars) + x + y + log(x^pars + y^pars) *(2/pars - 2) + (pars - 1)*log(x*y) + log(1 + (pars-1)*(x^pars + y^pars)^(-1/pars)) ) +
            #                0.5 * ( -(xn^pars + yn^pars)^(1/pars) + xn + yn + log(xn^pars + yn^pars) *(2/pars - 2) + (pars - 1)*log(xn*yn) + log(1 + (pars-1)*(xn^pars + yn^pars)^(-1/pars)) )
            # } else {
            #     x = - log(1-u); y = - log(v);
            #     xn = - log(u); yn = - log(1-v);
            #     npars = -pars
            #     density <- 0.5 * ( -(x^npars + y^npars)^(1/npars) + x + y + log(x^npars + y^npars) *(2/npars - 2) + (npars - 1)*log(x*y) + log(1 + (npars-1)*(x^npars + y^npars)^(-1/npars)) ) +
            #                0.5 * ( -(xn^npars + yn^npars)^(1/npars) + xn + yn + log(xn^npars + yn^npars) *(2/npars - 2) + (npars - 1)*log(xn*yn) + log(1 + (npars-1)*(xn^npars + yn^npars)^(-1/npars)) )
            #     }
            # return(density)
                x = - log(u); y = - log(v);
                xn = - log(1-u); yn = - log(1-v);
                apars = abs(pars)

            density <- ifelse(pars > 0,
                              0.5 * ( -(x^apars + y^apars)^(1/apars) + x + y + log(x^apars + y^apars) *(2/apars - 2) + (apars - 1)*log(x*y) + log(1 + (apars-1)*(x^apars + y^apars)^(-1/apars)) ) +
                              0.5 * ( -(xn^apars + yn^apars)^(1/apars) + xn + yn + log(xn^apars + yn^apars) *(2/apars - 2) + (apars - 1)*log(xn*yn) + log(1 + (apars-1)*(xn^apars + yn^apars)^(-1/apars)) ),
                              0.5 * ( -(xn^apars + y^apars)^(1/apars) + xn + y + log(xn^apars + y^apars) *(2/apars - 2) + (apars - 1)*log(xn*y) + log(1 + (apars-1)*(xn^apars + y^apars)^(-1/apars)) ) +
                              0.5 * ( -(x^apars + yn^apars)^(1/apars) + x + yn + log(x^apars + yn^apars) *(2/apars - 2) + (apars - 1)*log(x*yn) + log(1 + (apars-1)*(x^apars + yn^apars)^(-1/apars)) )
                                  )
            return(density)
        }
        )
    }

    if (family == 5) {
        return(function(u,v, pars) {
            #log(BiCopPDF(u1 = u, u2 = v, family = 5, par = pars) )
            exp_theta = exp(pars); exp_theta_u = exp_theta^u; exp_theta_v = exp_theta^v;
            return( log(pars * (exp_theta -1) ) + pars * (u + v + 1) -
                        2 * log(abs(exp_theta_u * exp_theta_v - (exp_theta_u * exp_theta) - (exp_theta_v * exp_theta) + exp_theta)) )
        }
        )
    }

    if (family == 6) {
        return(function(u,v, pars) {
            #log(BiCopPDF(u1 = u, u2 = v, family = 6, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 16, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 26, par = pars) )
            #log(BiCopPDF(u1 = u, u2 = v, family = 36, par = pars) )
          apars = abs(pars)

          om_u = 1 - u; om_v = 1 - v;
          t_u = om_u^apars; t_v = om_v^apars;
          t_uv = t_u + t_v - t_u * t_v;

          t_nu = u^apars; t_nv = v^apars;
          t_nunv = t_nu + t_nv - t_nu * t_nv;

          t_nuv = t_nu + t_v - t_nu * t_v;
          t_unv = t_u + t_nv - t_u * t_nv;




          density <- ifelse(pars > 0, 0.5 * ( log(t_uv) * (1/apars-2) + log(apars - 1 + t_uv) + (apars - 1) * log(om_u) + (apars - 1) * log(om_v) ) +
                                      0.5 * ( log(t_nunv) * (1/apars-2) + log(apars - 1 + t_nunv) + (apars - 1) * log(u) + (apars - 1) * log(v) ),
                                      0.5 * ( log(t_nuv) * (1/apars-2) + log(apars - 1 + t_nuv) + (apars - 1) * log(u) + (apars - 1) * log(om_v) ) +
                                      0.5 * ( log(t_unv) * (1/apars-2) + log(apars - 1 + t_unv) + (apars - 1) * log(om_u) + (apars - 1) * log(v) )
            )
            return(density)

        }
        )
    }
}

#' @export
BiCopSimMod <- function(N,family, par, par2){
    if( family == 3 || family == 4 || family == 6){
        indicator <- (runif(1) > 0.5)
        if (par > 0){
            return( indicator * BiCopSim(N = N,family = family, par = par, par2 = par2) +
                        (1-indicator) * BiCopSim(N = N,family = family+10, par = par, par2 = par2) )
        } else {
            return( indicator * BiCopSim(N = N,family = family + 20, par = par, par2 = par2) +
                        (1-indicator) * BiCopSim(N = N,family = family + 30, par = par, par2 = par2) )
        }
    } else {
        return(BiCopSim(N = N,family = family, par = par, par2 = par2))
    }
}

#' @export
BicopParamRestrict <- function(family){
        if (family == 1 || family == 2) {
            return(function(tau) sin(tau * pi / 2) )
        }
        if (family == 3) {
            return(function(tau) ifelse(tau > 0, 2*tau/(1-tau), 2*tau/(1+tau) ) )
        }
        if (family == 4) {
            return(function(tau) ifelse(tau > 0, 1/(1-tau), -1/(1+tau) ))
        }
        if (family == 5){
            return(function(tau) approx(x = TauVals, y = frankParGrid, xout = tau)$y)
        }
        if (family == 6) {
            #return(function(tau){ return(BiCopTau2Par(family = family, tau = tau, check.taus = FALSE)) })
              return(function(tau) approx(x = TauVals, y = JoeParGrid, xout = tau)$y)
        }
}
# BicopParamRestrict <- function(family){
#     return(function(tau){ return(BiCopTau2Par(family = family, tau = tau, check.taus = FALSE)) })
# }
# BicopParamRestrict <- function(family){
#     if (family == 1 || family == 2) {
#         return(restrict(LB = -0.99, UB = 0.99))
#     }
#     if (family == 3 || family == 13 || family == 7 || family == 17) {
#         return(restrict(LB = 0.1, UB = 50))
#     }
#     if (family == 23 || family == 33|| family == 27 || family == 37) {
#         return(restrict(LB = -50, UB = -0.1))
#     }
#     if (family == 4 || family == 14 || family == 6 || family == 16) {
#         return(restrict(LB = 1.05, UB = 30))
#     }
#     if (family == 24 || family == 34 || family == 26 || family == 36) {
#         return(restrict(LB = -30, UB = -1.05))
#     }
#     if (family == 5) {
#         return(restrict(LB = -100, UB = 100))
#     }
# }
JoeParGrid = c( -50.000000, -49.037573, -48.017903, -46.998256, -45.978633, -44.959037, -43.939468,
                -42.919930, - 41.900423, - 40.880951, - 39.861516, - 38.842122, - 37.822770, - 36.803466,
                -35.784212, - 34.765013, - 33.745875, - 32.726802, - 31.707802, - 30.688881, - 29.670047,
                -28.651310, - 27.632680, - 26.614170, - 25.595793, - 24.577566, - 23.559509, - 22.541644,
                -21.523998, - 20.506604, - 19.489501, - 18.472736, - 17.456368, - 16.440471, - 15.425135,
                -14.410480, - 13.396659, - 12.383875, - 11.372405, - 10.362630, -  9.355102, -  8.350634,
                -7.350493, - 6.356755, - 5.373055, -4.406226, -3.469896, -2.591465, -1.820464,
                -1.221506, -1.01, 1.01,
                1.221506,  1.820464,  2.591465,  3.469896,  4.406226,  5.373055,
                6.356755,  7.350493 , 8.350634,  9.355102, 10.362630, 11.372405, 12.383875,
                13.396659, 14.410480, 15.425135, 16.440471, 17.456368, 18.472736, 19.489501,
                20.506604, 21.523998, 22.541644, 23.559509, 24.577566, 25.595793, 26.614170,
                27.632680, 28.651310, 29.670047, 30.688881, 31.707802, 32.726802, 33.745875,
                34.765013, 35.784212, 36.803466, 37.822770, 38.842122, 39.861516, 40.880951,
                41.900423, 42.919930, 43.939468, 44.959037, 45.978633, 46.998256, 48.017903,
                49.037573, 50.000000)
frankParGrid = c(-101, -98.959595959596, -96.9191919191919, -94.8787878787879,
  -92.8383838383838, -90.7979797979798, -88.7575757575758, -86.7171717171717,
  -84.6767676767677, -82.6363636363636, -80.5959595959596, -78.5555555555556,
  -76.5151515151515, -74.4747474747475, -72.4343434343434, -70.3939393939394,
  -68.3535353535354, -66.3131313131313, -64.2727272727273, -62.2323232323232,
  -60.1919191919192, -58.1515151515152, -56.1111111111111, -54.0707070707071,
  -52.030303030303, -49.989898989899, -47.949494949495, -45.9090909090909,
  -43.8686868686869, -41.8282828282828, -39.7878787878788, -37.7474747474748,
  -35.7070707070707, -33.6666666666667, -31.6262626262626, -29.5858585858586,
  -27.5454545454545, -25.5050505050505, -23.4646464646465, -21.4242424242424,
  -19.3838383838384, -17.3434343434344, -15.3030303030303, -13.2626262626263,
  -11.2222222222222, -9.18181818181819, -7.14141414141415, -5.1010101010101,
  -3.06060606060606, -1.02020202020203, - 0.01, 0.01,
  1.02020202020201, 3.06060606060605,
  5.10101010101009, 7.14141414141413, 9.18181818181817, 11.2222222222222,
  13.2626262626263, 15.3030303030303, 17.3434343434343, 19.3838383838384,
  21.4242424242424, 23.4646464646464, 25.5050505050505, 27.5454545454545,
  29.5858585858586, 31.6262626262626, 33.6666666666667, 35.7070707070707,
  37.7474747474747, 39.7878787878788, 41.8282828282828, 43.8686868686869,
  45.9090909090909, 47.9494949494949, 49.989898989899, 52.030303030303,
  54.070707070707, 56.1111111111111, 58.1515151515151, 60.1919191919192,
  62.2323232323232, 64.2727272727273, 66.3131313131313, 68.3535353535353,
  70.3939393939394, 72.4343434343434, 74.4747474747475, 76.5151515151515,
  78.5555555555555, 80.5959595959596, 82.6363636363636, 84.6767676767677,
  86.7171717171717, 88.7575757575758, 90.7979797979798, 92.8383838383838,
  94.8787878787879, 96.9191919191919, 98.9595959595959, 101)

TauVals = c(-0.961041048550867, -0.960251344564296, -0.95942897342536,
  -0.958571866033333, -0.957677774843704, -0.956744254215267,
  -0.955768638102463, -0.954748014665184, -0.953679197287614,
  -0.952558691399602, -0.951382656374172, -0.950146861627529,
  -0.948846635866317, -0.947476808201624, -0.946031639568512,
  -0.944504742537972, -0.942888987164558, -0.941176389950323,
  -0.93935798228736, -0.937423653818046, -0.935361964957013, -0.933159921260012,
  -0.930802700275106, -0.928273318793382, -0.925552224778557,
  -0.922616793339209, -0.919440699396042, -0.91599313043174, -0.912237789768897,
  -0.908131622511068, -0.903623170019409, -0.898650420568253,
  -0.893137967278655, -0.886993199334039, -0.880101121990825,
  -0.872317196660623, -0.863457265500544, -0.853283089132126,
  -0.84148112450054, -0.827630609937665, -0.811154246217934, -0.791239672221123,
  -0.766710388198721, -0.73580674780385, -0.69580488947752, -0.642352809081713,
  -0.568396118348008, -0.462982587231658, -0.312511738501557,
  -0.112196429394003, -0.000000000000001, 0.000000000000001, 0.112196429394, 0.312511738501556, 0.462982587231657,
  0.568396118348008, 0.642352809081712, 0.695804889477519, 0.73580674780385,
  0.76671038819872, 0.791239672221123, 0.811154246217934, 0.827630609937665,
  0.84148112450054, 0.853283089132126, 0.863457265500544, 0.872317196660623,
  0.880101121990825, 0.886993199334039, 0.893137967278656, 0.898650420568252,
  0.903623170019409, 0.908131622511068, 0.912237789768897, 0.91599313043174,
  0.919440699396043, 0.92261679333921, 0.925552224778557, 0.928273318793382,
  0.930802700275106, 0.933159921260012, 0.935361964957013, 0.937423653818045,
  0.93935798228736, 0.941176389950323, 0.942888987164558, 0.944504742537972,
  0.946031639568512, 0.947476808201624, 0.948846635866317, 0.950146861627529,
  0.951382656374172, 0.952558691399602, 0.953679197287614, 0.954748014665184,
  0.955768638102463, 0.956744254215266, 0.957677774843704, 0.958571866033333,
  0.95942897342536, 0.960251344564296, 0.961041048550867)
